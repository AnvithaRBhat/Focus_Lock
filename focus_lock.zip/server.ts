import express from "express";
import type { Request, Response } from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured in environment variables.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

interface FilePayload {
  mimeType: string;
  data: string;
  name?: string;
}

interface GenerateQuestionsBody {
  materialText?: string;
  fileData?: FilePayload | null;
  questionCount?: number;
  difficulty?: string;
  activityType?: string;
  taskTarget?: string;
  appNames?: string[];
}

interface EvaluateAnswersBody {
  materialText?: string;
  fileData?: FilePayload | null;
  questions?: Array<{
    id: string;
    prompt: string;
    focusArea?: string;
    expectedPoints?: string;
  }>;
  answers?: Array<{
    questionId: string;
    answerText: string;
  }>;
  passingScore?: number;
  difficulty?: string;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "20mb" }));

  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.post("/api/gemini/generate-questions", async (req: Request, res: Response) => {
    try {
      const body = req.body as GenerateQuestionsBody;
      const materialText = (body.materialText ?? "").trim();
      const fileData = body.fileData ?? null;
      const questionCount = Math.min(Math.max(Number(body.questionCount) || 5, 1), 10);
      const difficulty = body.difficulty || "Standard";
      const activityType = body.activityType || "Reading";
      const taskTarget = body.taskTarget || "5 pages";
      const appNames = Array.isArray(body.appNames) && body.appNames.length > 0
        ? body.appNames.join(", ")
        : "protected applications";

      if (!materialText && !fileData?.data) {
        res.status(400).json({
          error: "Please submit your reading notes, summary, or attach a study document first.",
        });
        return;
      }

      const ai = getGeminiClient();

      const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];

      if (fileData?.data && fileData?.mimeType) {
        parts.push({
          inlineData: {
            mimeType: fileData.mimeType,
            data: fileData.data,
          },
        });
      }

      const promptText = [
        `You are the academic verification engine for FOCUSLOCK, a productivity app where users earn access to distracting apps (${appNames}) by demonstrating real comprehension of their completed ${activityType} task (${taskTarget}).`,
        `Generate exactly ${questionCount} distinct comprehension questions based strictly on the provided study material.`,
        `Difficulty level: ${difficulty}.`,
        difficulty === "Foundational"
          ? "Focus on clear recall of core concepts, key definitions, and main ideas directly stated in the material."
          : difficulty === "Challenging"
            ? "Focus on synthesis, cause-and-effect reasoning, edge cases, and applying concepts from the material."
            : "Balance conceptual understanding, key mechanisms, and accurate explanation in the learner's own words.",
        "Each question should be answerable in 1–4 concise sentences based on the submitted material.",
        materialText ? `\nSubmitted learner notes / summary:\n${materialText}` : "",
      ]
        .filter(Boolean)
        .join("\n");

      parts.push({ text: promptText });

      const response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: { parts },
        config: {
          systemInstruction:
            "Generate accurate, clear comprehension questions strictly grounded in the user's submitted study material or attached document. Do not invent facts outside the material.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              topicTitle: {
                type: Type.STRING,
                description: "Short 3-6 word title summarizing the submitted study material.",
              },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    prompt: {
                      type: Type.STRING,
                      description: "The question text presented to the learner.",
                    },
                    focusArea: {
                      type: Type.STRING,
                      description: "2-4 word concept label tested by this question.",
                    },
                    expectedPoints: {
                      type: Type.STRING,
                      description: "Key facts or reasoning expected in a strong answer.",
                    },
                  },
                  required: ["id", "prompt", "focusArea", "expectedPoints"],
                },
              },
            },
            required: ["topicTitle", "questions"],
          },
        },
      });

      const rawText = (response.text ?? "{}").trim();
      const parsed = JSON.parse(rawText) as {
        topicTitle?: string;
        questions?: Array<{
          id: string;
          prompt: string;
          focusArea: string;
          expectedPoints: string;
        }>;
      };

      const questions = (parsed.questions ?? []).slice(0, questionCount).map((q, idx) => ({
        id: q.id || `q-${idx + 1}`,
        prompt: q.prompt,
        focusArea: q.focusArea || "Comprehension",
        expectedPoints: q.expectedPoints || "",
      }));

      res.json({
        topicTitle: parsed.topicTitle || "Submitted Study Material",
        questions,
      });
    } catch (error) {
      console.error("Error generating questions:", error);
      const message =
        error instanceof Error ? error.message : "Failed to generate comprehension questions.";
      res.status(500).json({ error: message });
    }
  });

  app.post("/api/gemini/evaluate-answers", async (req: Request, res: Response) => {
    try {
      const body = req.body as EvaluateAnswersBody;
      const materialText = (body.materialText ?? "").trim();
      const fileData = body.fileData ?? null;
      const questions = body.questions ?? [];
      const answers = body.answers ?? [];
      const passingScore = Math.min(Math.max(Number(body.passingScore) || 70, 40), 100);
      const difficulty = body.difficulty || "Standard";

      if (questions.length === 0) {
        res.status(400).json({ error: "No questions provided for evaluation." });
        return;
      }

      const ai = getGeminiClient();
      const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];

      if (fileData?.data && fileData?.mimeType) {
        parts.push({
          inlineData: {
            mimeType: fileData.mimeType,
            data: fileData.data,
          },
        });
      }

      const qaPairs = questions.map((q, idx) => {
        const match = answers.find((a) => a.questionId === q.id);
        return {
          index: idx + 1,
          questionId: q.id,
          question: q.prompt,
          expectedPoints: q.expectedPoints ?? "",
          userAnswer: (match?.answerText ?? "").trim() || "(No answer provided)",
        };
      });

      const evalPrompt = [
        "Evaluate the learner's answers against the submitted study material and expected concepts.",
        `Grading difficulty standard: ${difficulty}. Passing score threshold: ${passingScore}%.`,
        "Score each question fairly from 0 to 100 based on accuracy, completeness, and genuine understanding (not exact wording). Empty, off-topic, or nonsensical answers must score 0-15.",
        "Provide concise, specific 1-2 sentence feedback for each answer explaining what was accurate or what was missing.",
        materialText ? `\nSource study notes:\n${materialText}` : "",
        `\nQuestions & Learner Answers:\n${JSON.stringify(qaPairs, null, 2)}`,
      ]
        .filter(Boolean)
        .join("\n");

      parts.push({ text: evalPrompt });

      const response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: { parts },
        config: {
          systemInstruction:
            "You are a fair, rigorous academic evaluator for FOCUSLOCK. Grade answers objectively against the source material and return structured JSON.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              overallScore: {
                type: Type.INTEGER,
                description: "Average score across all questions from 0 to 100.",
              },
              summaryFeedback: {
                type: Type.STRING,
                description: "1-2 sentence overall assessment of comprehension.",
              },
              evaluations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    questionId: { type: Type.STRING },
                    score: { type: Type.INTEGER },
                    isCorrect: { type: Type.BOOLEAN },
                    feedback: { type: Type.STRING },
                  },
                  required: ["questionId", "score", "isCorrect", "feedback"],
                },
              },
            },
            required: ["overallScore", "summaryFeedback", "evaluations"],
          },
        },
      });

      const rawText = (response.text ?? "{}").trim();
      const parsed = JSON.parse(rawText) as {
        overallScore?: number;
        summaryFeedback?: string;
        evaluations?: Array<{
          questionId: string;
          score: number;
          isCorrect: boolean;
          feedback: string;
        }>;
      };

      const evaluations = (parsed.evaluations ?? []).map((ev) => ({
        questionId: ev.questionId,
        score: Math.min(Math.max(Math.round(ev.score), 0), 100),
        isCorrect: Boolean(ev.isCorrect),
        feedback: ev.feedback || "Evaluated.",
      }));

      const computedAvg =
        evaluations.length > 0
          ? Math.round(evaluations.reduce((sum, e) => sum + e.score, 0) / evaluations.length)
          : Math.round(parsed.overallScore ?? 0);

      const passed = computedAvg >= passingScore;

      res.json({
        overallScore: computedAvg,
        passed,
        summaryFeedback:
          parsed.summaryFeedback ||
          (passed
            ? "Comprehension threshold met. Your answers demonstrate clear understanding."
            : `Score is below the ${passingScore}% passing requirement. Review the feedback and try again.`),
        evaluations,
      });
    } catch (error) {
      console.error("Error evaluating answers:", error);
      const message =
        error instanceof Error ? error.message : "Failed to evaluate your answers.";
      res.status(500).json({ error: message });
    }
  });

  if (process.env.NODE_ENV === "production") {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("/{*splat}", (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`FOCUSLOCK server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
