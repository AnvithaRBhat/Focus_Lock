export type ActivityType = "Reading" | "Writing" | "Assignment" | "Revision";

export type DifficultyLevel = "Foundational" | "Standard" | "Challenging";

export type AppCategory = "Social" | "Video" | "Gaming" | "Entertainment" | "Messaging";

export type AppLockStatus = "locked" | "in_progress" | "unlocked";

export interface UnlockRule {
  id: string;
  name: string;
  activityType: ActivityType;
  targetAmount: number;
  targetUnit: string;
  questionCount: number;
  difficulty: DifficultyLevel;
  passingScore: number;
  unlockDurationMinutes: number;
  isSharedRule: boolean;
}

export interface ProtectedApp {
  id: string;
  name: string;
  category: AppCategory;
  accentColor: string;
  isProtected: boolean;
  ruleId: string;
  status: AppLockStatus;
  currentLevel: 1 | 2 | 3;
  unlockedUntil: number | null;
  lastUnlockedAt: number | null;
}

export interface GeneratedQuestion {
  id: string;
  prompt: string;
  focusArea: string;
  expectedPoints: string;
}

export interface QuestionEvaluation {
  questionId: string;
  score: number;
  isCorrect: boolean;
  feedback: string;
}

export interface EvaluationResult {
  overallScore: number;
  passed: boolean;
  summaryFeedback: string;
  evaluations: QuestionEvaluation[];
}

export interface UnlockSessionRecord {
  id: string;
  timestamp: number;
  appIds: string[];
  appNames: string[];
  ruleName: string;
  activityType: ActivityType;
  targetSummary: string;
  topicTitle: string;
  questionCount: number;
  difficulty: DifficultyLevel;
  score: number;
  passed: boolean;
  durationMinutes: number;
}

export interface FocusSessionState {
  isActive: boolean;
  durationMinutes: number;
  startedAt: number | null;
  endsAt: number | null;
  label: string;
}

export interface UploadedEvidenceFile {
  name: string;
  mimeType: string;
  data: string;
  sizeBytes: number;
}
