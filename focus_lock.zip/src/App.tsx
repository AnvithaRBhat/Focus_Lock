import { useEffect, useMemo, useRef, useState } from "react";
import {
  LayoutGrid,
  SlidersHorizontal,
  Shield,
  BarChart3,
  Timer,
  Plus,
  Lock,
  LockOpen,
  Clock,
  Search,
  ArrowRight,
  Layers,
  Trash2,
  ExternalLink,
  Menu,
  X,
} from "lucide-react";
import { DEFAULT_APPS, DEFAULT_RULES, INITIAL_HISTORY } from "./data/defaults";
import type {
  FocusSessionState,
  ProtectedApp,
  UnlockRule,
  UnlockSessionRecord,
} from "./types";
import { AppGlyph } from "./components/AppGlyph";
import { AddAppModal } from "./components/AddAppModal";
import { RuleEditorModal } from "./components/RuleEditorModal";
import { UnlockWorkflowModal } from "./components/UnlockWorkflowModal";
import { ProtectedAppPreviewModal } from "./components/ProtectedAppPreviewModal";
import { FocusModeView } from "./components/FocusModeView";
import { ProgressLogView } from "./components/ProgressLogView";
import { TaskRulesView } from "./components/TaskRulesView";
import { GuidedLockFlow } from "./components/GuidedLockFlow";
import type { LockWorkflowPhase } from "./components/GuidedLockFlow";

type NavSection = "guided" | "vault" | "rules" | "focus" | "progress";
type StatusFilter = "all" | "locked" | "in_progress" | "unlocked";

const STORAGE_KEYS = {
  apps: "focuslock_apps_v1",
  rules: "focuslock_rules_v1",
  history: "focuslock_history_v1",
  focus: "focuslock_focus_v1",
  guided: "focuslock_guided_v1",
  usage: "focuslock_usage_seconds_v1",
};

interface GuidedState {
  phase: LockWorkflowPhase;
  prescribedMinutes: number;
  blockedAppIds: string[];
  allowedAppIds: string[];
  startedAt: number | null;
  endsAt: number | null;
}

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [activeNav, setActiveNav] = useState<NavSection>("guided");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [apps, setApps] = useState<ProtectedApp[]>(() =>
    loadFromStorage(STORAGE_KEYS.apps, DEFAULT_APPS),
  );
  const [rules, setRules] = useState<UnlockRule[]>(() =>
    loadFromStorage(STORAGE_KEYS.rules, DEFAULT_RULES),
  );
  const [history, setHistory] = useState<UnlockSessionRecord[]>(() =>
    loadFromStorage(STORAGE_KEYS.history, INITIAL_HISTORY),
  );
  const [focusSession, setFocusSession] = useState<FocusSessionState>(() =>
    loadFromStorage(STORAGE_KEYS.focus, {
      isActive: false,
      durationMinutes: 25,
      startedAt: null,
      endsAt: null,
      label: "Deep Study Sprint",
    }),
  );

  const [guidedState, setGuidedState] = useState<GuidedState>(() =>
    loadFromStorage(STORAGE_KEYS.guided, {
      phase: "set_time",
      prescribedMinutes: 25,
      blockedAppIds: DEFAULT_APPS.slice(0, 5).map((a) => a.id),
      allowedAppIds: DEFAULT_APPS.slice(5).map((a) => a.id),
      startedAt: null,
      endsAt: null,
    }),
  );

  const [totalAppUsageSeconds, setTotalAppUsageSeconds] = useState<number>(() =>
    loadFromStorage(STORAGE_KEYS.usage, 0),
  );

  const [now, setNow] = useState(() => Date.now());
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const [addAppOpen, setAddAppOpen] = useState(false);
  const [ruleEditorState, setRuleEditorState] = useState<{
    open: boolean;
    rule: UnlockRule | null;
    preselectedAppId?: string | null;
  }>({ open: false, rule: null, preselectedAppId: null });
  const [unlockModalState, setUnlockModalState] = useState<{
    open: boolean;
    targetApps: ProtectedApp[];
    rule: UnlockRule | null;
  }>({ open: false, targetApps: [], rule: null });
  const [previewApp, setPreviewApp] = useState<ProtectedApp | null>(null);

  const completionHandledRef = useRef(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.apps, JSON.stringify(apps));
  }, [apps]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.rules, JSON.stringify(rules));
  }, [rules]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.history, JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.focus, JSON.stringify(focusSession));
  }, [focusSession]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.guided, JSON.stringify(guidedState));
  }, [guidedState]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.usage, JSON.stringify(totalAppUsageSeconds));
  }, [totalAppUsageSeconds]);

  // 1-second timer tick for guided Focus_Lock timer, app usage tracking, and unlock expiry
  useEffect(() => {
    const interval = window.setInterval(() => {
      const currentTime = Date.now();
      setNow(currentTime);
      setTotalAppUsageSeconds((prev) => prev + 1);

      setApps((prevApps) => {
        let changed = false;
        const next = prevApps.map((app) => {
          if (
            app.status === "unlocked" &&
            app.unlockedUntil !== null &&
            currentTime >= app.unlockedUntil
          ) {
            changed = true;
            return {
              ...app,
              status: "locked" as const,
              currentLevel: 1 as const,
              unlockedUntil: null,
            };
          }
          return app;
        });
        return changed ? next : prevApps;
      });

      setFocusSession((prevFocus) => {
        if (
          prevFocus.isActive &&
          prevFocus.endsAt !== null &&
          currentTime >= prevFocus.endsAt
        ) {
          return {
            ...prevFocus,
            isActive: false,
            startedAt: null,
            endsAt: null,
          };
        }
        return prevFocus;
      });
    }, 1000);

    return () => window.clearInterval(interval);
  }, []);

  // Handle Guided Focus_Lock timer completion & restore access to all paused/blocked apps
  useEffect(() => {
    if (
      guidedState.phase === "running" &&
      guidedState.endsAt !== null &&
      now >= guidedState.endsAt &&
      !completionHandledRef.current
    ) {
      completionHandledRef.current = true;
      const currentTime = now;

      const restoredNames = apps
        .filter((a) => guidedState.blockedAppIds.includes(a.id))
        .map((a) => a.name);

      setApps((prevApps) =>
        prevApps.map((app) =>
          guidedState.blockedAppIds.includes(app.id) ||
          guidedState.allowedAppIds.includes(app.id)
            ? {
                ...app,
                status: "unlocked",
                currentLevel: 3,
                unlockedUntil: null,
                lastUnlockedAt: currentTime,
              }
            : app,
        ),
      );

      const record: UnlockSessionRecord = {
        id: `focus-timer-${currentTime}`,
        timestamp: currentTime,
        appIds: guidedState.blockedAppIds,
        appNames: restoredNames.length > 0 ? restoredNames : ["Blocked Apps"],
        ruleName: "Focus_Lock Prescribed Timer",
        activityType: "Revision",
        targetSummary: `${guidedState.prescribedMinutes} min lock completed`,
        topicTitle: `Completed ${guidedState.prescribedMinutes}-Min App Lock`,
        questionCount: 0,
        difficulty: "Standard",
        score: 100,
        passed: true,
        durationMinutes: guidedState.prescribedMinutes,
      };
      setHistory((prevHist) => [record, ...prevHist]);

      setGuidedState((prev) => ({
        ...prev,
        phase: "completed",
      }));

      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        try {
          new Notification("Focus_Lock — Time Ended", {
            body: "Congratulations, you haven't unlocked those apps. Access has been restored.",
          });
        } catch {
          // Ignore notification errors in sandboxed iframes
        }
      }
    }
  }, [
    guidedState.phase,
    guidedState.endsAt,
    guidedState.blockedAppIds,
    guidedState.allowedAppIds,
    guidedState.prescribedMinutes,
    now,
    apps,
  ]);

  const rulesById = useMemo(() => {
    const map = new Map<string, UnlockRule>();
    for (const r of rules) map.set(r.id, r);
    return map;
  }, [rules]);

  const sharedRules = useMemo(() => {
    return rules.filter((r) => apps.filter((a) => a.ruleId === r.id && a.isProtected).length > 1);
  }, [rules, apps]);

  const filteredApps = useMemo(() => {
    return apps.filter((app) => {
      const matchesStatus = statusFilter === "all" || app.status === statusFilter;
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q ||
        app.name.toLowerCase().includes(q) ||
        app.category.toLowerCase().includes(q);
      return matchesStatus && matchesSearch;
    });
  }, [apps, statusFilter, searchQuery]);

  const protectedCount = apps.filter((a) => a.isProtected).length;
  const lockedCount = apps.filter((a) => a.isProtected && a.status !== "unlocked").length;
  const completedLevelsCount =
    history.length * 3 +
    apps.reduce((sum, a) => sum + (a.status === "in_progress" ? a.currentLevel - 1 : 0), 0);
  const avgQuizScore =
    history.length > 0
      ? Math.round(history.reduce((sum, h) => sum + h.score, 0) / history.length)
      : 0;

  const remainingFocusSeconds =
    focusSession.isActive && focusSession.endsAt
      ? Math.max(0, Math.ceil((focusSession.endsAt - now) / 1000))
      : 0;

  const guidedRemainingSeconds =
    guidedState.phase === "running" && guidedState.endsAt
      ? Math.max(0, Math.ceil((guidedState.endsAt - now) / 1000))
      : 0;

  const guidedElapsedSeconds =
    guidedState.startedAt !== null
      ? guidedState.phase === "running"
        ? Math.max(0, Math.floor((now - guidedState.startedAt) / 1000))
        : guidedState.phase === "completed"
          ? guidedState.prescribedMinutes * 60
          : 0
      : 0;

  const formatCountdown = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  };

  // Guided Flow Handlers
  const handleToggleGuidedApp = (appId: string, mode: "block" | "allow") => {
    setGuidedState((prev) => {
      if (mode === "block") {
        const blocked = prev.blockedAppIds.includes(appId)
          ? prev.blockedAppIds
          : [...prev.blockedAppIds, appId];
        const allowed = prev.allowedAppIds.filter((id) => id !== appId);
        return { ...prev, blockedAppIds: blocked, allowedAppIds: allowed };
      } else {
        const allowed = prev.allowedAppIds.includes(appId)
          ? prev.allowedAppIds
          : [...prev.allowedAppIds, appId];
        const blocked = prev.blockedAppIds.filter((id) => id !== appId);
        return { ...prev, blockedAppIds: blocked, allowedAppIds: allowed };
      }
    });
  };

  const handleStartGuidedTimer = () => {
    completionHandledRef.current = false;
    const startedAt = Date.now();
    const endsAt = startedAt + guidedState.prescribedMinutes * 60 * 1000;

    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }

    // Lock blocked apps and grant access to allowed apps
    setApps((prev) =>
      prev.map((app) => {
        if (guidedState.blockedAppIds.includes(app.id)) {
          return {
            ...app,
            isProtected: true,
            status: "locked",
            currentLevel: 1,
            unlockedUntil: null,
          };
        }
        return {
          ...app,
          status: "unlocked",
          unlockedUntil: null,
        };
      }),
    );

    setGuidedState((prev) => ({
      ...prev,
      phase: "running",
      startedAt,
      endsAt,
    }));
  };

  const handleResetGuidedWorkflow = () => {
    completionHandledRef.current = false;
    setGuidedState((prev) => ({
      ...prev,
      phase: "set_time",
      startedAt: null,
      endsAt: null,
    }));
  };

  const handleAddApp = (newApp: ProtectedApp) => {
    setApps((prev) => [newApp, ...prev]);
    setGuidedState((prev) => ({
      ...prev,
      blockedAppIds: [...prev.blockedAppIds, newApp.id],
    }));
  };

  const handleStartUnlockForApp = (app: ProtectedApp) => {
    const rule = rulesById.get(app.ruleId) ?? rules[0] ?? null;
    if (!rule) return;

    const appsSharingRule = apps.filter((a) => a.ruleId === rule.id && a.isProtected);
    const targetApps =
      appsSharingRule.length > 1 && rule.isSharedRule ? appsSharingRule : [app];

    setUnlockModalState({
      open: true,
      targetApps,
      rule,
    });
  };

  const handleStartUnlockForRule = (rule: UnlockRule) => {
    const targetApps = apps.filter((a) => a.ruleId === rule.id);
    if (targetApps.length === 0) return;
    setUnlockModalState({
      open: true,
      targetApps,
      rule,
    });
  };

  const handleCompleteUnlock = (
    unlockedAppIds: string[],
    record: UnlockSessionRecord,
  ) => {
    const unlockedUntil = Date.now() + record.durationMinutes * 60 * 1000;
    setApps((prev) =>
      prev.map((app) =>
        unlockedAppIds.includes(app.id)
          ? {
              ...app,
              status: "unlocked",
              currentLevel: 3,
              unlockedUntil,
              lastUnlockedAt: Date.now(),
            }
          : app,
      ),
    );
    setHistory((prev) => [record, ...prev]);
  };

  const handleUpdateLevelProgress = (appIds: string[], level: 1 | 2 | 3) => {
    setApps((prev) =>
      prev.map((app) =>
        appIds.includes(app.id) && app.status !== "unlocked"
          ? { ...app, status: "in_progress", currentLevel: level }
          : app,
      ),
    );
  };

  const handleRelockApp = (appId: string) => {
    setApps((prev) =>
      prev.map((app) =>
        app.id === appId
          ? { ...app, status: "locked", currentLevel: 1, unlockedUntil: null }
          : app,
      ),
    );
  };

  const handleToggleAppProtection = (appId: string) => {
    setApps((prev) =>
      prev.map((app) =>
        app.id === appId
          ? {
              ...app,
              isProtected: !app.isProtected,
              status: !app.isProtected ? "locked" : app.status,
              unlockedUntil: !app.isProtected ? null : app.unlockedUntil,
            }
          : app,
      ),
    );
  };

  const handleDeleteApp = (appId: string) => {
    setApps((prev) => prev.filter((a) => a.id !== appId));
    setGuidedState((prev) => ({
      ...prev,
      blockedAppIds: prev.blockedAppIds.filter((id) => id !== appId),
      allowedAppIds: prev.allowedAppIds.filter((id) => id !== appId),
    }));
  };

  const handleSaveRule = (savedRule: UnlockRule, assignedAppIds: string[]) => {
    setRules((prev) => {
      const exists = prev.some((r) => r.id === savedRule.id);
      return exists
        ? prev.map((r) => (r.id === savedRule.id ? savedRule : r))
        : [...prev, savedRule];
    });

    if (assignedAppIds.length > 0) {
      setApps((prev) =>
        prev.map((app) =>
          assignedAppIds.includes(app.id) ? { ...app, ruleId: savedRule.id } : app,
        ),
      );
    }
  };

  const handleDeleteRule = (ruleId: string) => {
    setRules((prev) => prev.filter((r) => r.id !== ruleId));
  };

  const handleStartFocus = (durationMinutes: number, label: string) => {
    const startedAt = Date.now();
    const endsAt = startedAt + durationMinutes * 60 * 1000;
    setFocusSession({
      isActive: true,
      durationMinutes,
      startedAt,
      endsAt,
      label,
    });
    setApps((prev) =>
      prev.map((app) =>
        app.isProtected
          ? { ...app, status: "locked", currentLevel: 1, unlockedUntil: null }
          : app,
      ),
    );
  };

  const handleStopFocus = () => {
    setFocusSession((prev) => ({
      ...prev,
      isActive: false,
      startedAt: null,
      endsAt: null,
    }));
  };

  const navItems: Array<{ id: NavSection; label: string; icon: typeof LayoutGrid }> = [
    { id: "guided", label: "Lock Timer", icon: Timer },
    { id: "vault", label: "App Vault", icon: LayoutGrid },
    { id: "rules", label: "Task Rules", icon: SlidersHorizontal },
    { id: "focus", label: "Focus Mode", icon: Shield },
    { id: "progress", label: "Progress Log", icon: BarChart3 },
  ];

  const sectionBreadcrumbs: Record<NavSection, string> = {
    guided: "Lock Timer",
    vault: "App Vault",
    rules: "Task Rules",
    focus: "Focus Mode",
    progress: "Progress Log",
  };

  return (
    <div className="min-h-screen flex bg-[#071124] text-slate-100">
      {/* Left Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#0B1830] border-r border-[#1E335C] flex flex-col justify-between transition-transform duration-200 lg:static lg:translate-x-0 ${
          mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div>
          <div className="h-16 px-6 flex items-center justify-between border-b border-[#1E335C]">
            <a
              href="#guided"
              onClick={(e) => {
                e.preventDefault();
                setActiveNav("guided");
              }}
              className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap"
            >
              Focus_Lock
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg"
              aria-label="Close navigation menu"
            >
              <X size={18} />
            </button>
          </div>

          <nav className="p-4 space-y-1" aria-label="Primary navigation">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveNav(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                    active
                      ? "bg-blue-600/20 text-blue-300"
                      : "text-slate-300 hover:bg-[#13264A] hover:text-white"
                  }`}
                >
                  <Icon size={17} className={active ? "text-blue-400" : "text-slate-400"} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-[#1E335C] space-y-3">
          {guidedState.phase === "running" ? (
            <div className="p-3.5 rounded-lg bg-blue-950/60 border border-blue-600/60 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-blue-200">
                <span>Timer Running</span>
                <span className="font-mono tabular-nums">
                  {formatCountdown(guidedRemainingSeconds)}
                </span>
              </div>
              <p className="text-xs text-slate-300 truncate">
                {guidedState.blockedAppIds.length} apps blocked
              </p>
              <button
                type="button"
                onClick={() => setActiveNav("guided")}
                className="text-xs font-medium text-blue-300 hover:underline"
              >
                View Status
              </button>
            </div>
          ) : focusSession.isActive ? (
            <div className="p-3.5 rounded-lg bg-amber-950/60 border border-amber-700/70 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-amber-300">
                <span>Focus Shield Active</span>
                <span className="font-mono tabular-nums">
                  {formatCountdown(remainingFocusSeconds)}
                </span>
              </div>
              <p className="text-xs text-slate-200 truncate">{focusSession.label}</p>
              <button
                type="button"
                onClick={() => setActiveNav("focus")}
                className="text-xs font-medium text-amber-200 hover:underline"
              >
                Manage Session
              </button>
            </div>
          ) : (
            <div className="space-y-1.5">
              <p className="text-xs font-medium text-white">
                Earn your screen time
              </p>
              <p className="text-xs text-slate-400 leading-relaxed">
                Lock distracting apps for your prescribed time or complete AI-verified study levels.
              </p>
            </div>
          )}
        </div>
      </aside>

      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar Contract */}
        <header className="h-16 bg-[#0B1830] border-b border-[#1E335C] px-6 flex items-center justify-between gap-8 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-2 text-slate-300 hover:text-white rounded-lg"
              aria-label="Open navigation menu"
            >
              <Menu size={20} />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-slate-400 whitespace-nowrap">Focus_Lock</span>
              <span className="text-slate-600">/</span>
              <h1 className="font-semibold text-white truncate">
                {sectionBreadcrumbs[activeNav]}
              </h1>
            </div>
          </div>

          <div className="shrink-0">
            {activeNav === "rules" ? (
              <button
                type="button"
                onClick={() =>
                  setRuleEditorState({ open: true, rule: null, preselectedAppId: null })
                }
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0"
              >
                <Plus size={15} />
                New Unlock Rule
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setAddAppOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0"
              >
                <Plus size={15} />
                Protect App
              </button>
            )}
          </div>
        </header>

        {/* Main Viewport */}
        <main className="flex-1 p-6 max-w-[1280px] w-full mx-auto space-y-6">
          {activeNav === "guided" && (
            <GuidedLockFlow
              apps={apps}
              history={history}
              phase={guidedState.phase}
              prescribedMinutes={guidedState.prescribedMinutes}
              blockedAppIds={guidedState.blockedAppIds}
              allowedAppIds={guidedState.allowedAppIds}
              remainingSeconds={guidedRemainingSeconds}
              sessionElapsedSeconds={guidedElapsedSeconds}
              totalAppUsageSeconds={totalAppUsageSeconds}
              onChangePrescribedMinutes={(mins) =>
                setGuidedState((prev) => ({ ...prev, prescribedMinutes: mins }))
              }
              onGoToSelectApps={() =>
                setGuidedState((prev) => ({ ...prev, phase: "select_apps" }))
              }
              onBackToSetTime={() =>
                setGuidedState((prev) => ({ ...prev, phase: "set_time" }))
              }
              onToggleAppAccess={handleToggleGuidedApp}
              onStartTimer={handleStartGuidedTimer}
              onResetWorkflow={handleResetGuidedWorkflow}
              onOpenAddApp={() => setAddAppOpen(true)}
              onTryOpenApp={(app) => setPreviewApp(app)}
            />
          )}

          {activeNav === "vault" && (
            <>
              <section className="space-y-4">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-white">
                      Protected Applications
                    </h2>
                    <p className="text-sm text-slate-300 mt-1">
                      Complete each app&apos;s required reading and comprehension sequence to unlock timed access.
                    </p>
                  </div>

                  {sharedRules.length > 0 && (
                    <button
                      type="button"
                      onClick={() => handleStartUnlockForRule(sharedRules[0])}
                      className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-blue-200 bg-blue-600/20 border border-blue-500/40 rounded-lg hover:bg-blue-600/35 transition-colors whitespace-nowrap shrink-0 self-start md:self-auto"
                    >
                      <Layers size={15} />
                      Unlock Shared Group ({sharedRules[0].name})
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 bg-[#0F1F3D] border border-[#1E335C] rounded-xl divide-y lg:divide-y-0 lg:divide-x divide-[#1E335C]">
                  <div className="p-5">
                    <p className="text-xs font-medium text-slate-400">Protected Apps</p>
                    <p className="text-2xl font-bold font-mono tabular-nums text-white mt-1">
                      {protectedCount}
                    </p>
                  </div>
                  <div className="p-5">
                    <p className="text-xs font-medium text-slate-400">Pending Unlock Tasks</p>
                    <p className="text-2xl font-bold font-mono tabular-nums text-white mt-1">
                      {lockedCount}
                    </p>
                  </div>
                  <div className="p-5">
                    <p className="text-xs font-medium text-slate-400">Completed Levels</p>
                    <p className="text-2xl font-bold font-mono tabular-nums text-white mt-1">
                      {completedLevelsCount}
                    </p>
                  </div>
                  <div className="p-5">
                    <p className="text-xs font-medium text-slate-400">Avg. Quiz Score</p>
                    <p className="text-2xl font-bold font-mono tabular-nums text-emerald-400 mt-1">
                      {avgQuizScore}%
                    </p>
                  </div>
                </div>
              </section>

              <section className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-1 p-1 bg-[#0F1F3D] border border-[#1E335C] rounded-lg self-start">
                  {(
                    [
                      { key: "all", label: "All Apps" },
                      { key: "locked", label: "Locked" },
                      { key: "in_progress", label: "In Progress" },
                      { key: "unlocked", label: "Unlocked" },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.key}
                      type="button"
                      onClick={() => setStatusFilter(tab.key)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                        statusFilter === tab.key
                          ? "bg-blue-600 text-white"
                          : "text-slate-300 hover:text-white"
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <Search
                    size={15}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Filter applications..."
                    className="pl-9 pr-3 py-1.5 text-sm bg-[#0F1F3D] border border-[#1E335C] rounded-lg text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-64"
                  />
                </div>
              </section>

              {filteredApps.length === 0 ? (
                <div className="p-12 bg-[#0F1F3D] border border-[#1E335C] rounded-xl text-center space-y-3">
                  <p className="text-sm font-semibold text-white">
                    No applications match this filter
                  </p>
                  <p className="text-xs text-slate-400">
                    Adjust your filter or add a new application to Focus_Lock protection.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setStatusFilter("all");
                      setSearchQuery("");
                    }}
                    className="px-4 py-2 text-xs font-medium text-blue-200 bg-blue-600/25 border border-blue-500/40 rounded-lg hover:bg-blue-600/40 transition-colors"
                  >
                    Reset Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {filteredApps.map((app) => {
                    const rule = rulesById.get(app.ruleId) ?? rules[0];
                    const remainingSecs =
                      app.status === "unlocked" && app.unlockedUntil
                        ? Math.max(0, Math.ceil((app.unlockedUntil - now) / 1000))
                        : 0;
                    const isTimerBlocked =
                      guidedState.phase === "running" &&
                      guidedState.blockedAppIds.includes(app.id);
                    const isUnlocked =
                      !isTimerBlocked &&
                      !focusSession.isActive &&
                      app.isProtected &&
                      app.status === "unlocked" &&
                      (remainingSecs > 0 || app.unlockedUntil === null);

                    const sharedSiblings = rule
                      ? apps.filter((a) => a.ruleId === rule.id && a.id !== app.id)
                      : [];

                    return (
                      <div
                        key={app.id}
                        className="p-5 bg-[#0F1F3D] border border-[#1E335C] rounded-xl flex flex-col justify-between gap-4"
                      >
                        <div className="space-y-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-center gap-3 min-w-0">
                              <AppGlyph
                                name={app.name}
                                category={app.category}
                                accentColor={app.accentColor}
                              />
                              <div className="min-w-0">
                                <h3 className="text-base font-semibold text-white truncate">
                                  {app.name}
                                </h3>
                                <p className="text-xs text-slate-400 truncate">
                                  {app.category}
                                  {rule ? ` · ${rule.name}` : ""}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-3 shrink-0">
                              {isTimerBlocked ? (
                                <span className="inline-flex items-center gap-1.5 text-xs font-semibold font-mono tabular-nums text-rose-400">
                                  <Lock size={13} />
                                  Blocked · {formatCountdown(guidedRemainingSeconds)}
                                </span>
                              ) : !app.isProtected ? (
                                <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-400">
                                  Paused
                                </span>
                              ) : focusSession.isActive ? (
                                <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-300">
                                  <Shield size={13} />
                                  Focus Locked
                                </span>
                              ) : isUnlocked ? (
                                <span className="inline-flex items-center gap-1.5 text-xs font-semibold font-mono tabular-nums text-emerald-400">
                                  <LockOpen size={13} />
                                  {remainingSecs > 0
                                    ? `Unlocked · ${formatCountdown(remainingSecs)}`
                                    : "Unlocked"}
                                </span>
                              ) : app.status === "in_progress" ? (
                                <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-300">
                                  <Clock size={13} />
                                  Level {app.currentLevel} Pending
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-400">
                                  <Lock size={13} />
                                  Locked
                                </span>
                              )}

                              <button
                                type="button"
                                onClick={() => handleToggleAppProtection(app.id)}
                                role="switch"
                                aria-checked={app.isProtected}
                                aria-label={`Toggle protection for ${app.name}`}
                                className={`w-9 h-5 rounded-full transition-colors p-0.5 flex items-center ${
                                  app.isProtected ? "bg-blue-600 justify-end" : "bg-slate-600 justify-start"
                                }`}
                              >
                                <span className="w-4 h-4 rounded-full bg-white shadow-sm" />
                              </button>
                            </div>
                          </div>

                          {rule && (
                            <div className="px-3.5 py-2.5 rounded-lg bg-[#0A1730] border border-[#1E335C] text-xs text-slate-300 leading-relaxed">
                              <span className="font-medium text-white">
                                {rule.activityType} {rule.targetAmount} {rule.targetUnit}
                              </span>{" "}
                              → Submit summary → Answer {rule.questionCount} questions → Unlock{" "}
                              {app.name}
                              {sharedSiblings.length > 0 && (
                                <span className="block text-[11px] text-slate-400 mt-1">
                                  Shared sequence also unlocks: {sharedSiblings.map((s) => s.name).join(", ")}
                                </span>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#1E335C]">
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                setRuleEditorState({
                                  open: true,
                                  rule: rule ?? null,
                                  preselectedAppId: app.id,
                                })
                              }
                              className="px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white hover:bg-[#162B52] rounded-lg transition-colors whitespace-nowrap"
                            >
                              Edit Rule
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteApp(app.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/60 rounded-lg transition-colors"
                              aria-label={`Remove ${app.name}`}
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() => setPreviewApp(app)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap shrink-0"
                            >
                              <ExternalLink size={13} />
                              Open
                            </button>

                            {app.isProtected && !isUnlocked && !isTimerBlocked && !focusSession.isActive && (
                              <button
                                type="button"
                                onClick={() => handleStartUnlockForApp(app)}
                                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0"
                              >
                                Start Unlock
                                <ArrowRight size={13} />
                              </button>
                            )}

                            {isUnlocked && (
                              <button
                                type="button"
                                onClick={() => handleRelockApp(app.id)}
                                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-slate-200 bg-[#162B52] hover:bg-[#1E3868] rounded-lg transition-colors whitespace-nowrap shrink-0"
                              >
                                <Lock size={13} />
                                Re-lock
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {activeNav === "rules" && (
            <TaskRulesView
              rules={rules}
              apps={apps}
              onCreateRule={() =>
                setRuleEditorState({ open: true, rule: null, preselectedAppId: null })
              }
              onEditRule={(rule) =>
                setRuleEditorState({ open: true, rule, preselectedAppId: null })
              }
              onDeleteRule={handleDeleteRule}
              onUnlockByRule={handleStartUnlockForRule}
            />
          )}

          {activeNav === "focus" && (
            <FocusModeView
              apps={apps}
              focusSession={focusSession}
              remainingFocusSeconds={remainingFocusSeconds}
              onStartFocus={handleStartFocus}
              onStopFocus={handleStopFocus}
              onTryOpenApp={(app) => setPreviewApp(app)}
            />
          )}

          {activeNav === "progress" && (
            <ProgressLogView
              history={history}
              onClearHistory={() => setHistory([])}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <AddAppModal
        isOpen={addAppOpen}
        rules={rules}
        onClose={() => setAddAppOpen(false)}
        onAddApp={handleAddApp}
      />

      {ruleEditorState.open && (
        <RuleEditorModal
          isOpen={ruleEditorState.open}
          editingRule={ruleEditorState.rule}
          apps={apps}
          preselectedAppId={ruleEditorState.preselectedAppId}
          onClose={() =>
            setRuleEditorState({ open: false, rule: null, preselectedAppId: null })
          }
          onSaveRule={handleSaveRule}
        />
      )}

      {unlockModalState.open && (
        <UnlockWorkflowModal
          isOpen={unlockModalState.open}
          targetApps={unlockModalState.targetApps}
          rule={unlockModalState.rule}
          onClose={() =>
            setUnlockModalState({ open: false, targetApps: [], rule: null })
          }
          onCompleteUnlock={handleCompleteUnlock}
          onUpdateLevelProgress={handleUpdateLevelProgress}
        />
      )}

      <ProtectedAppPreviewModal
        app={previewApp}
        rule={previewApp ? rulesById.get(previewApp.ruleId) ?? rules[0] ?? null : null}
        focusSession={focusSession}
        remainingUnlockSeconds={
          previewApp && previewApp.unlockedUntil
            ? Math.max(0, Math.ceil((previewApp.unlockedUntil - now) / 1000))
            : 0
        }
        isTimerBlocked={
          Boolean(previewApp) &&
          guidedState.phase === "running" &&
          guidedState.blockedAppIds.includes(previewApp!.id)
        }
        timerRemainingSeconds={guidedRemainingSeconds}
        onClose={() => setPreviewApp(null)}
        onStartUnlock={handleStartUnlockForApp}
        onRelockApp={handleRelockApp}
      />
    </div>
  );
}
