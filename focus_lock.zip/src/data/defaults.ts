import type { ProtectedApp, UnlockRule, UnlockSessionRecord } from "../types";

export const DEFAULT_RULES: UnlockRule[] = [
  {
    id: "rule-youtube",
    name: "Deep Reading & Recall",
    activityType: "Reading",
    targetAmount: 5,
    targetUnit: "pages",
    questionCount: 5,
    difficulty: "Standard",
    passingScore: 70,
    unlockDurationMinutes: 30,
    isSharedRule: false,
  },
  {
    id: "rule-social-shared",
    name: "Common Social Unlock Sequence",
    activityType: "Reading",
    targetAmount: 4,
    targetUnit: "pages",
    questionCount: 5,
    difficulty: "Standard",
    passingScore: 70,
    unlockDurationMinutes: 25,
    isSharedRule: true,
  },
  {
    id: "rule-gaming",
    name: "Assignment & Problem Proof",
    activityType: "Assignment",
    targetAmount: 45,
    targetUnit: "minutes",
    questionCount: 5,
    difficulty: "Challenging",
    passingScore: 80,
    unlockDurationMinutes: 45,
    isSharedRule: false,
  },
  {
    id: "rule-revision",
    name: "Active Concept Revision",
    activityType: "Revision",
    targetAmount: 3,
    targetUnit: "chapters",
    questionCount: 3,
    difficulty: "Foundational",
    passingScore: 70,
    unlockDurationMinutes: 20,
    isSharedRule: false,
  },
];

export const DEFAULT_APPS: ProtectedApp[] = [
  {
    id: "app-youtube",
    name: "YouTube",
    category: "Video",
    accentColor: "#DC2626",
    isProtected: true,
    ruleId: "rule-youtube",
    status: "locked",
    currentLevel: 1,
    unlockedUntil: null,
    lastUnlockedAt: null,
  },
  {
    id: "app-instagram",
    name: "Instagram",
    category: "Social",
    accentColor: "#DB2777",
    isProtected: true,
    ruleId: "rule-social-shared",
    status: "locked",
    currentLevel: 1,
    unlockedUntil: null,
    lastUnlockedAt: null,
  },
  {
    id: "app-tiktok",
    name: "TikTok",
    category: "Video",
    accentColor: "#0F172A",
    isProtected: true,
    ruleId: "rule-social-shared",
    status: "locked",
    currentLevel: 1,
    unlockedUntil: null,
    lastUnlockedAt: null,
  },
  {
    id: "app-facebook",
    name: "Facebook",
    category: "Social",
    accentColor: "#2563EB",
    isProtected: true,
    ruleId: "rule-social-shared",
    status: "locked",
    currentLevel: 1,
    unlockedUntil: null,
    lastUnlockedAt: null,
  },
  {
    id: "app-gaming",
    name: "Valorant / Mobile Games",
    category: "Gaming",
    accentColor: "#7C3AED",
    isProtected: true,
    ruleId: "rule-gaming",
    status: "locked",
    currentLevel: 1,
    unlockedUntil: null,
    lastUnlockedAt: null,
  },
  {
    id: "app-discord",
    name: "Discord",
    category: "Messaging",
    accentColor: "#4F46E5",
    isProtected: true,
    ruleId: "rule-revision",
    status: "locked",
    currentLevel: 1,
    unlockedUntil: null,
    lastUnlockedAt: null,
  },
];

export const INITIAL_HISTORY: UnlockSessionRecord[] = [
  {
    id: "hist-1",
    timestamp: Date.now() - 1000 * 60 * 60 * 5,
    appIds: ["app-youtube"],
    appNames: ["YouTube"],
    ruleName: "Deep Reading & Recall",
    activityType: "Reading",
    targetSummary: "5 pages completed",
    topicTitle: "Cognitive Load & Working Memory",
    questionCount: 5,
    difficulty: "Standard",
    score: 88,
    passed: true,
    durationMinutes: 30,
  },
  {
    id: "hist-2",
    timestamp: Date.now() - 1000 * 60 * 60 * 26,
    appIds: ["app-instagram", "app-tiktok", "app-facebook"],
    appNames: ["Instagram", "TikTok", "Facebook"],
    ruleName: "Common Social Unlock Sequence",
    activityType: "Reading",
    targetSummary: "4 pages completed",
    topicTitle: "Spaced Repetition Mechanics",
    questionCount: 5,
    difficulty: "Standard",
    score: 82,
    passed: true,
    durationMinutes: 25,
  },
];

export const SAMPLE_STUDY_MATERIALS = [
  {
    title: "Cognitive Load Theory & Attention",
    text: `Cognitive Load Theory, developed by John Sweller in the late 1980s, explains how human working memory processes information during learning. Because working memory can hold only a small number of novel elements simultaneously (typically 4 to 7 chunks), instructional tasks must manage three types of cognitive load: intrinsic, extraneous, and germane.

Intrinsic load reflects the inherent complexity of the subject matter and how many concepts interact at once. Extraneous load comes from poor presentation or environmental distractions—such as switching between study notes and social media notifications—which consumes working memory without aiding learning. Germane load is the productive mental effort dedicated to building durable mental schemas in long-term memory.

Research shows that frequent task-switching introduces an "attention residue," where part of a learner's cognitive capacity remains stuck on the previous distracting app for 15 to 23 minutes. By completing a continuous reading block and actively recalling core ideas before checking entertainment apps, learners reduce extraneous load and strengthen germane schema formation.`,
  },
  {
    title: "Distributed Systems: Raft Consensus",
    text: `Raft is a consensus algorithm designed to manage a replicated log across a cluster of servers while remaining easier to understand than Paxos. A Raft cluster elects a single distinguished leader, which takes complete responsibility for managing the replicated log. Each server is always in one of three states: Leader, Follower, or Candidate.

Time in Raft is divided into numbered terms that act as logical clocks. If a follower receives no heartbeat communication from a leader within an election timeout, it increments its current term, transitions to candidate state, votes for itself, and sends RequestVote RPCs to other nodes. A candidate becomes leader if it receives votes from a majority of the cluster in the same term.

Once elected, the leader accepts client commands, appends them to its local log, and issues AppendEntries RPCs in parallel to followers. When a majority of servers have safely written the entry, the leader commits the entry and notifies followers to apply it to their state machines, guaranteeing safety even if minority nodes fail.`,
  },
];
