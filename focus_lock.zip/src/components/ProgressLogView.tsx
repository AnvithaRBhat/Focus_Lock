import React, { useMemo, useState } from "react";
import { Download, Search, CheckCircle2, Trash2 } from "lucide-react";
import type { UnlockSessionRecord } from "../types";

interface ProgressLogViewProps {
  history: UnlockSessionRecord[];
  onClearHistory: () => void;
}

export const ProgressLogView: React.FC<ProgressLogViewProps> = ({
  history,
  onClearHistory,
}) => {
  const [search, setSearch] = useState("");
  const [activityFilter, setActivityFilter] = useState<string>("All");

  const filtered = useMemo(() => {
    return history.filter((item) => {
      const matchesActivity =
        activityFilter === "All" || item.activityType === activityFilter;
      const q = search.trim().toLowerCase();
      const matchesQuery =
        !q ||
        item.topicTitle.toLowerCase().includes(q) ||
        item.appNames.some((n) => n.toLowerCase().includes(q)) ||
        item.ruleName.toLowerCase().includes(q);
      return matchesActivity && matchesQuery;
    });
  }, [history, search, activityFilter]);

  const avgScore =
    history.length > 0
      ? Math.round(history.reduce((sum, r) => sum + r.score, 0) / history.length)
      : 0;

  const totalEarnedMinutes = history.reduce((sum, r) => sum + r.durationMinutes, 0);

  const handleExportCsv = () => {
    const headers = [
      "Date",
      "Topic",
      "Applications",
      "Activity",
      "Target",
      "Questions",
      "Difficulty",
      "Score (%)",
      "Earned (mins)",
    ];
    const rows = filtered.map((r) => [
      new Date(r.timestamp).toISOString(),
      `"${r.topicTitle.replace(/"/g, '""')}"`,
      `"${r.appNames.join(", ")}"`,
      r.activityType,
      `"${r.targetSummary}"`,
      r.questionCount,
      r.difficulty,
      r.score,
      r.durationMinutes,
    ]);
    const csv = [headers.join(","), ...rows.map((row) => row.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "focuslock-progress-log.csv";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 bg-[#0F1F3D] border border-[#1E335C] rounded-xl divide-y sm:divide-y-0 sm:divide-x divide-[#1E335C]">
        <div className="p-5">
          <p className="text-xs font-medium text-slate-400">Verified Unlock Sessions</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-white mt-1">
            {history.length}
          </p>
        </div>
        <div className="p-5">
          <p className="text-xs font-medium text-slate-400">Average Comprehension Score</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-emerald-400 mt-1">
            {avgScore}%
          </p>
        </div>
        <div className="p-5">
          <p className="text-xs font-medium text-slate-400">Total Screen Time Earned</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-white mt-1">
            {totalEarnedMinutes} mins
          </p>
        </div>
      </div>

      <div className="bg-[#0F1F3D] border border-[#1E335C] rounded-xl overflow-hidden">
        <div className="p-4 border-b border-[#1E335C] flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search
                size={15}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search topics or apps..."
                className="pl-9 pr-3 py-1.5 text-sm bg-[#0A1730] border border-[#263D6B] rounded-lg text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 w-60"
              />
            </div>

            <div className="flex items-center gap-1 p-1 bg-[#0A1730] border border-[#1E335C] rounded-lg">
              {["All", "Reading", "Writing", "Assignment", "Revision"].map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setActivityFilter(tab)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    activityFilter === tab
                      ? "bg-blue-600 text-white"
                      : "text-slate-300 hover:text-white"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleExportCsv}
              disabled={filtered.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
            >
              <Download size={14} />
              Export CSV
            </button>
            {history.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-[#13264A] border border-[#263D6B] rounded-lg hover:text-rose-300 hover:border-rose-700/60 transition-colors whitespace-nowrap shrink-0"
              >
                <Trash2 size={14} />
                Clear Log
              </button>
            )}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <p className="text-sm font-medium text-white">No verification records match</p>
            <p className="text-xs text-slate-400">
              Complete a Level 1–3 unlock sequence on any protected app to record your progress here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#1E335C] bg-[#0B1830] text-xs font-medium text-slate-400">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Study Topic</th>
                  <th className="py-3 px-4">Apps Unlocked</th>
                  <th className="py-3 px-4">Task Target</th>
                  <th className="py-3 px-4 text-right">Questions</th>
                  <th className="py-3 px-4 text-right">Quiz Score</th>
                  <th className="py-3 px-4 text-right">Earned Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E335C] text-sm">
                {filtered.map((record) => (
                  <tr key={record.id} className="hover:bg-[#13264A]/60 transition-colors">
                    <td className="py-3 px-4 font-mono text-xs tabular-nums text-slate-400 whitespace-nowrap">
                      {new Date(record.timestamp).toLocaleDateString(undefined, {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-medium text-white">{record.topicTitle}</p>
                      <p className="text-xs text-slate-400">
                        {record.ruleName} · {record.difficulty}
                      </p>
                    </td>
                    <td className="py-3 px-4 text-slate-200">
                      {record.appNames.join(", ")}
                    </td>
                    <td className="py-3 px-4 text-slate-300 text-xs">
                      {record.activityType} · {record.targetSummary}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">
                      {record.questionCount}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="inline-flex items-center justify-end gap-1 font-mono font-semibold tabular-nums text-emerald-400">
                        <CheckCircle2 size={14} />
                        {record.score}%
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200 whitespace-nowrap">
                      {record.durationMinutes} min
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
