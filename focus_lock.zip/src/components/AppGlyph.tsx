import React from "react";
import { Gamepad2, Globe, MessageSquare, Tv } from "lucide-react";
import type { AppCategory } from "../types";

interface AppGlyphProps {
  name: string;
  category: AppCategory;
  accentColor: string;
  size?: "sm" | "md" | "lg";
}

export const AppGlyph: React.FC<AppGlyphProps> = ({
  name,
  category,
  accentColor,
  size = "md",
}) => {
  const lower = name.toLowerCase();

  const dimensions =
    size === "sm"
      ? "w-8 h-8 rounded-lg"
      : size === "lg"
        ? "w-12 h-12 rounded-xl"
        : "w-10 h-10 rounded-xl";

  const iconSize = size === "sm" ? 16 : size === "lg" ? 22 : 18;

  // Exact YouTube Logo
  if (lower.includes("youtube")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 overflow-hidden bg-white border border-slate-200`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 28 20" className="w-[74%] h-[74%]" fill="none">
          <path
            d="M27.42 3.12A3.51 3.51 0 0 0 24.95.63C22.77 0 14 0 14 0S5.23 0 3.05.63A3.51 3.51 0 0 0 .58 3.12C0 5.32 0 10 0 10s0 4.68.58 6.88a3.51 3.51 0 0 0 2.47 2.49C5.23 20 14 20 14 20s8.77 0 10.95-.63a3.51 3.51 0 0 0 2.47-2.49C28 14.68 28 10 28 10s0-4.68-.58-6.88Z"
            fill="#FF0000"
          />
          <path d="M11.2 14.29 18.48 10 11.2 5.71v8.58Z" fill="#FFFFFF" />
        </svg>
      </div>
    );
  }

  const uniqueId = React.useId();

  // Exact Instagram Logo
  if (lower.includes("instagram")) {
    const gradId = `ig-grad-${uniqueId}`;
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 overflow-hidden`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-full h-full" fill="none">
          <defs>
            <radialGradient id={gradId} cx="30%" cy="107%" r="150%">
              <stop offset="0%" stopColor="#fdf497" />
              <stop offset="5%" stopColor="#fdf497" />
              <stop offset="45%" stopColor="#fd5949" />
              <stop offset="60%" stopColor="#d6249f" />
              <stop offset="90%" stopColor="#285AEB" />
            </radialGradient>
          </defs>
          <rect width="24" height="24" rx="5.5" fill={`url(#${gradId})`} />
          <rect
            x="4.75"
            y="4.75"
            width="14.5"
            height="14.5"
            rx="4.2"
            stroke="#FFFFFF"
            strokeWidth="1.65"
          />
          <circle cx="12" cy="12" r="3.45" stroke="#FFFFFF" strokeWidth="1.65" />
          <circle cx="16.1" cy="7.9" r="1.05" fill="#FFFFFF" />
        </svg>
      </div>
    );
  }

  // Exact TikTok Logo
  if (lower.includes("tiktok")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#010101]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[68%] h-[68%]" fill="none">
          <path
            d="M16.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298 0 .593.045.875.134V9.4a6.33 6.33 0 0 0-.875-.062A6.34 6.34 0 0 0 3.74 21.15a6.34 6.34 0 0 0 9.08-5.73V8.76a8.18 8.18 0 0 0 4.77 1.52V6.84c-.34-.03-.675-.08-1-.15Z"
            fill="#25F4EE"
            transform="translate(-0.75, -0.75)"
          />
          <path
            d="M16.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298 0 .593.045.875.134V9.4a6.33 6.33 0 0 0-.875-.062A6.34 6.34 0 0 0 3.74 21.15a6.34 6.34 0 0 0 9.08-5.73V8.76a8.18 8.18 0 0 0 4.77 1.52V6.84c-.34-.03-.675-.08-1-.15Z"
            fill="#FE2C55"
            transform="translate(0.75, 0.75)"
          />
          <path
            d="M16.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298 0 .593.045.875.134V9.4a6.33 6.33 0 0 0-.875-.062A6.34 6.34 0 0 0 3.74 21.15a6.34 6.34 0 0 0 9.08-5.73V8.76a8.18 8.18 0 0 0 4.77 1.52V6.84c-.34-.03-.675-.08-1-.15Z"
            fill="#FFFFFF"
          />
        </svg>
      </div>
    );
  }

  // Exact Facebook Logo
  if (lower.includes("facebook")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 overflow-hidden bg-[#1877F2]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[82%] h-[82%] mt-1" fill="none">
          <path
            d="M15.6 24v-9.2h3.1l.46-3.6H15.6V8.9c0-1.04.29-1.75 1.78-1.75h1.9V3.93c-.33-.04-1.46-.14-2.77-.14-2.74 0-4.62 1.67-4.62 4.75v2.66H8.8v3.6h3.09V24h3.71Z"
            fill="#FFFFFF"
          />
        </svg>
      </div>
    );
  }

  // Exact Discord Logo
  if (lower.includes("discord")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#5865F2]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[70%] h-[70%]" fill="none">
          <path
            d="M20.32 4.37a19.8 19.8 0 0 0-4.89-1.52.07.07 0 0 0-.08.04c-.21.38-.44.87-.61 1.25a18.27 18.27 0 0 0-5.48 0 12.64 12.64 0 0 0-.62-1.25.08.08 0 0 0-.08-.04 19.74 19.74 0 0 0-4.89 1.52.07.07 0 0 0-.03.03C.53 9.05-.32 13.58.1 18.06a.08.08 0 0 0 .03.06 19.9 19.9 0 0 0 5.99 3.03.08.08 0 0 0 .08-.03c.46-.63.87-1.3 1.23-2a.08.08 0 0 0-.04-.11 13.1 13.1 0 0 1-1.87-.89.08.08 0 0 1-.01-.13c.13-.09.25-.19.37-.29a.07.07 0 0 1 .08-.01c3.93 1.79 8.18 1.79 12.06 0a.07.07 0 0 1 .08.01c.12.1.24.2.37.29a.08.08 0 0 1-.01.13c-.6.35-1.22.65-1.87.89a.08.08 0 0 0-.04.11c.36.7.77 1.37 1.22 2a.08.08 0 0 0 .09.03 19.83 19.83 0 0 0 6-3.03.08.08 0 0 0 .03-.06c.5-5.18-.84-9.68-3.55-13.66a.06.06 0 0 0-.03-.03ZM8.02 15.33c-1.18 0-2.16-1.08-2.16-2.42 0-1.33.96-2.42 2.16-2.42 1.21 0 2.18 1.1 2.16 2.42 0 1.34-.96 2.42-2.16 2.42Zm7.97 0c-1.18 0-2.16-1.08-2.16-2.42 0-1.33.96-2.42 2.16-2.42 1.21 0 2.18 1.1 2.16 2.42 0 1.34-.95 2.42-2.16 2.42Z"
            fill="#FFFFFF"
          />
        </svg>
      </div>
    );
  }

  // Exact Valorant Logo
  if (lower.includes("valorant")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#FF4655]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[68%] h-[68%]" fill="none">
          <path
            d="M2.5 4.2v7.1l6.4 8h4.5L2.5 4.2Zm19 0-7.7 9.6h4.5l3.2-4V4.2Z"
            fill="#FFFFFF"
          />
        </svg>
      </div>
    );
  }

  // Exact X (Twitter) Logo
  if (lower === "x" || lower.includes("twitter") || lower.includes("x (")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#000000]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[64%] h-[64%]" fill="none">
          <path
            d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.45-6.231Zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77Z"
            fill="#FFFFFF"
          />
        </svg>
      </div>
    );
  }

  // Exact Netflix Logo
  if (lower.includes("netflix")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#141414]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[68%] h-[68%]" fill="none">
          <path d="M5.5 2h3.6v20H5.5V2Z" fill="#B20710" />
          <path d="M14.9 2h3.6v20h-3.6V2Z" fill="#B20710" />
          <path d="M5.5 2h3.6l9.4 20h-3.6L5.5 2Z" fill="#E50914" />
        </svg>
      </div>
    );
  }

  // Exact Reddit Logo
  if (lower.includes("reddit")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#FF4500]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[74%] h-[74%]" fill="none">
          <circle cx="12" cy="13.5" r="6.5" fill="#FFFFFF" />
          <circle cx="9.6" cy="13" r="1.15" fill="#FF4500" />
          <circle cx="14.4" cy="13" r="1.15" fill="#FF4500" />
          <circle cx="5.2" cy="11.5" r="1.6" fill="#FFFFFF" />
          <circle cx="18.8" cy="11.5" r="1.6" fill="#FFFFFF" />
          <path
            d="M12 7l1.3-3.7 3 .7"
            stroke="#FFFFFF"
            strokeWidth="1.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="17" cy="4.2" r="1.2" fill="#FFFFFF" />
          <path
            d="M9.6 16c1.2.9 3.6.9 4.8 0"
            stroke="#FF4500"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        </svg>
      </div>
    );
  }

  // Exact Twitch Logo
  if (lower.includes("twitch")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#9146FF]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[66%] h-[66%]" fill="none">
          <path
            d="M4.2 2 2 5.8v14.4h5V23l2.8-2.8h3.9l5.8-5.8V2H4.2Zm13.5 11.4-3.1 3.1H9.8L7.2 19v-2.5H4.2V4.1h13.5v9.3Z"
            fill="#FFFFFF"
          />
          <path d="M14.2 7.2h1.8v4.8h-1.8V7.2Zm-4.6 0h1.8v4.8H9.6V7.2Z" fill="#FFFFFF" />
        </svg>
      </div>
    );
  }

  // Exact Snapchat Logo
  if (lower.includes("snapchat")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#FFFC00] border border-yellow-300`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[70%] h-[70%]" fill="none">
          <path
            d="M12 3.2c-2.9 0-4.8 2-4.8 4.8v2.1c-.4.2-.9.2-1.3.1-.4-.1-.7.2-.6.6.2.5.8.8 1.4 1 .1.7-.3 1.7-1.7 2.5-.6.3-1.4.6-2 .8-.4.1-.5.6-.1.9.8.5 1.8.8 2.6 1 .2.5.4 1.1.8 1.2.5.1 1.2-.2 2.2-.2 1.1 0 1.8 1 3.5 1s2.4-1 3.5-1c1 0 1.7.3 2.2.2.4-.1.6-.7.8-1.2.8-.2 1.8-.5 2.6-1 .4-.3.3-.8-.1-.9-.6-.2-1.4-.5-2-.8-1.4-.8-1.8-1.8-1.7-2.5.6-.2 1.2-.5 1.4-1 .1-.4-.2-.7-.6-.6-.4.1-.9.1-1.3-.1V8c0-2.8-1.9-4.8-4.8-4.8Z"
            fill="#FFFFFF"
            stroke="#000000"
            strokeWidth="1.4"
            strokeLinejoin="round"
          />
        </svg>
      </div>
    );
  }

  // Exact Spotify Logo
  if (lower.includes("spotify")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#1DB954]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[70%] h-[70%]" fill="none">
          <path
            d="M5.5 9.5c4.6-1.4 9.6-1.1 13.7.8"
            stroke="#FFFFFF"
            strokeWidth="2.1"
            strokeLinecap="round"
          />
          <path
            d="M6.6 13c3.8-1.1 8-.8 11.4.8"
            stroke="#FFFFFF"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          <path
            d="M7.7 16.3c3-.8 6.3-.6 9 .7"
            stroke="#FFFFFF"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      </div>
    );
  }

  // Exact WhatsApp Logo
  if (lower.includes("whatsapp")) {
    return (
      <div
        className={`${dimensions} flex items-center justify-center shrink-0 bg-[#25D366]`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" className="w-[72%] h-[72%]" fill="none">
          <path
            d="M12 3.5a8.4 8.4 0 0 0-7.3 12.6L3.6 20.4l4.4-1.1A8.4 8.4 0 1 0 12 3.5Z"
            stroke="#FFFFFF"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
          <path
            d="M9.6 8.9c-.2-.4-.4-.4-.7-.4h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4s1 2.8 1.2 3c.1.2 2 3.2 4.9 4.4 2.4 1 2.9.8 3.4.7.5-.1 1.7-.7 1.9-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.7-.4-.4-.2-1.7-.8-1.9-.9-.3-.1-.5-.1-.7.2-.2.4-.7.9-.9 1.1-.2.2-.3.2-.7 0-.3-.2-1.4-.5-2.7-1.7-1-.9-1.7-2-1.9-2.3-.2-.3 0-.5.2-.7l.5-.6c.2-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.8-1.8Z"
            fill="#FFFFFF"
          />
        </svg>
      </div>
    );
  }

  // Fallback for custom user-added apps
  const renderFallbackIcon = () => {
    if (category === "Gaming") return <Gamepad2 size={iconSize} />;
    if (category === "Video" || category === "Entertainment") return <Tv size={iconSize} />;
    if (category === "Messaging") return <MessageSquare size={iconSize} />;
    return <Globe size={iconSize} />;
  };

  return (
    <div
      className={`${dimensions} flex items-center justify-center shrink-0 text-white`}
      style={{ backgroundColor: accentColor }}
      aria-hidden="true"
    >
      {renderFallbackIcon()}
    </div>
  );
};
