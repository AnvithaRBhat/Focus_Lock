import React, { useState } from "react";
import { X, ShieldPlus } from "lucide-react";
import type { AppCategory, ProtectedApp, UnlockRule } from "../types";

interface AddAppModalProps {
  isOpen: boolean;
  rules: UnlockRule[];
  onClose: () => void;
  onAddApp: (app: ProtectedApp) => void;
}

const PRESET_APPS: Array<{ name: string; category: AppCategory; color: string }> = [
  { name: "X (Twitter)", category: "Social", color: "#000000" },
  { name: "Netflix", category: "Entertainment", color: "#E50914" },
  { name: "Reddit", category: "Social", color: "#FF4500" },
  { name: "Twitch", category: "Video", color: "#9146FF" },
  { name: "Snapchat", category: "Messaging", color: "#FFFC00" },
  { name: "Spotify", category: "Entertainment", color: "#1DB954" },
  { name: "WhatsApp", category: "Messaging", color: "#25D366" },
];

const COLOR_OPTIONS = [
  "#2563EB",
  "#DC2626",
  "#DB2777",
  "#7C3AED",
  "#0F172A",
  "#059669",
  "#EA580C",
];

export const AddAppModal: React.FC<AddAppModalProps> = ({
  isOpen,
  rules,
  onClose,
  onAddApp,
}) => {
  const [name, setName] = useState("");
  const [category, setCategory] = useState<AppCategory>("Social");
  const [accentColor, setAccentColor] = useState("#2563EB");
  const [ruleId, setRuleId] = useState(rules[0]?.id ?? "");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) return;

    const newApp: ProtectedApp = {
      id: `app-${Date.now()}`,
      name: trimmed,
      category,
      accentColor,
      isProtected: true,
      ruleId: ruleId || rules[0]?.id || "",
      status: "locked",
      currentLevel: 1,
      unlockedUntil: null,
      lastUnlockedAt: null,
    };

    onAddApp(newApp);
    setName("");
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-[2px] p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="add-app-title"
    >
      <div className="w-full max-w-lg bg-[#0F1F3D] border border-[#1E335C] rounded-xl shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#1E335C]">
          <div className="flex items-center gap-2.5">
            <ShieldPlus size={18} className="text-blue-400" />
            <h2 id="add-app-title" className="text-base font-semibold text-white">
              Protect New Application
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#162B52] transition-colors"
            aria-label="Close modal"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <p className="text-xs font-medium text-slate-400 mb-2">Quick Select Popular Apps</p>
            <div className="flex flex-wrap gap-2">
              {PRESET_APPS.map((preset) => (
                <button
                  key={preset.name}
                  type="button"
                  onClick={() => {
                    setName(preset.name);
                    setCategory(preset.category);
                    setAccentColor(preset.color);
                  }}
                  className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#0A1730] hover:bg-[#162B52] border border-[#263D6B] rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  {preset.name}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="app-name-input" className="block text-sm font-medium text-slate-200 mb-1.5">
                Application Name
              </label>
              <input
                id="app-name-input"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Instagram, Steam"
                className="w-full px-3.5 py-2 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="app-category-select" className="block text-sm font-medium text-slate-200 mb-1.5">
                Category
              </label>
              <select
                id="app-category-select"
                value={category}
                onChange={(e) => setCategory(e.target.value as AppCategory)}
                className="w-full px-3.5 py-2 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Social">Social</option>
                <option value="Video">Video</option>
                <option value="Gaming">Gaming</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Messaging">Messaging</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="app-rule-select" className="block text-sm font-medium text-slate-200 mb-1.5">
              Unlock Rule Sequence
            </label>
            <select
              id="app-rule-select"
              value={ruleId}
              onChange={(e) => setRuleId(e.target.value)}
              className="w-full px-3.5 py-2 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {rules.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} ({r.activityType} {r.targetAmount} {r.targetUnit} · {r.questionCount} questions)
                </option>
              ))}
            </select>
          </div>

          <div>
            <span className="block text-sm font-medium text-slate-200 mb-2">
              Custom App Icon Color (Fallback)
            </span>
            <div className="flex items-center gap-2.5">
              {COLOR_OPTIONS.map((hex) => (
                <button
                  key={hex}
                  type="button"
                  onClick={() => setAccentColor(hex)}
                  className={`w-7 h-7 rounded-lg transition-transform ${
                    accentColor === hex ? "ring-2 ring-offset-2 ring-offset-[#0F1F3D] ring-blue-400 scale-105" : ""
                  }`}
                  style={{ backgroundColor: hex }}
                  aria-label={`Select color ${hex}`}
                />
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#1E335C]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap shrink-0"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0"
            >
              Add to Vault
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
