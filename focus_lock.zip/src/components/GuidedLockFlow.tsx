import React, { useState } from "react";
import {
  ArrowRight,
  ArrowLeft,
  Bell,
  CheckCircle2,
  Clock,
  Lock,
  LockOpen,
  Plus,
  RotateCcw,
  Shield,
  ShieldCheck,
} from "lucide-react";
import type { ProtectedApp, UnlockSessionRecord } from "../types";
import { AppGlyph } from "./AppGlyph";

export type LockWorkflowPhase = "set_time" | "select_apps" | "running" | "completed";

interface GuidedLockFlowProps {
  apps: ProtectedApp[];
  history: UnlockSessionRecord[];
  phase: LockWorkflowPhase;
  prescribedMinutes: number;
  blockedAppIds: string[];
  allowedAppIds: string[];
  remainingSeconds: number;
  sessionElapsedSeconds: number;
  totalAppUsageSeconds: number;
  onChangePrescribedMinutes: (mins: number) => void;
  onGoToSelectApps: () => void;
  onBackToSetTime: () => void;
  onToggleAppAccess: (appId: string, mode: "block" | "allow") => void;
  onStartTimer: () => void;
  onResetWorkflow: () => void;
  onOpenAddApp: () => void;
  onTryOpenApp: (app: ProtectedApp) => void;
}

const TIME_PRESETS = [1, 15, 25, 45, 60];

export const GuidedLockFlow: React.FC<GuidedLockFlowProps> = ({
  apps,
  history,
  phase,
  prescribedMinutes,
  blockedAppIds,
  allowedAppIds,
  remainingSeconds,
  sessionElapsedSeconds,
  totalAppUsageSeconds,
  onChangePrescribedMinutes,
  onGoToSelectApps,
  onBackToSetTime,
  onToggleAppAccess,
  onStartTimer,
  onResetWorkflow,
  onOpenAddApp,
  onTryOpenApp,
}) => {
  const [customInput, setCustomInput] = useState(String(prescribedMinutes));

  const formatTimer = (totalSecs: number) => {
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    if (hrs > 0) {
      return `${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    }
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  const blockedApps = apps.filter((a) => blockedAppIds.includes(a.id));
  const allowedApps = apps.filter((a) => allowedAppIds.includes(a.id));
  const protectedApps = apps.filter((a) => a.isProtected);
  const completedApps = apps.filter((a) => a.currentLevel === 3 || a.status === "unlocked");
  const totalCompletedSessions = history.length;

  const handleMinutesChange = (val: string) => {
    setCustomInput(val);
    const parsed = parseInt(val, 10);
    if (!Number.isNaN(parsed) && parsed > 0) {
      onChangePrescribedMinutes(Math.min(parsed, 480));
    }
  };

  const handleSelectPreset = (mins: number) => {
    setCustomInput(String(mins));
    onChangePrescribedMinutes(mins);
  };

  return (
    <div className="space-y-6">
      {/* Primary Opening Brand Banner */}
      <div className="p-6 bg-[#0F1F3D] border border-[#1E335C] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white font-display">
            Focus_Lock
          </h2>
          <p className="text-sm text-slate-300 mt-1">
            Set your prescribed lock duration, choose which apps to block or allow, and lock distractions out until time ends.
          </p>
        </div>

        <div className="flex items-center gap-6 shrink-0 text-xs">
          <div>
            <span className="block text-slate-400">Time Using Focus_Lock</span>
            <span className="font-mono text-base font-semibold tabular-nums text-white">
              {formatTimer(totalAppUsageSeconds)}
            </span>
          </div>
          <div className="h-8 w-px bg-[#1E335C]" aria-hidden="true" />
          <div>
            <span className="block text-slate-400">Completed Levels</span>
            <span className="font-mono text-base font-semibold tabular-nums text-emerald-400">
              {totalCompletedSessions * 3}
            </span>
          </div>
        </div>
      </div>

      {/* Step 1: Enter Prescribed Time */}
      {phase === "set_time" && (
        <div className="p-6 bg-[#0F1F3D] border border-[#1E335C] rounded-xl space-y-6">
          <div className="space-y-1">
            <p className="text-xs font-medium text-blue-400">Step 1 of 2</p>
            <h3 className="text-xl font-semibold text-white">
              Enter Prescribed Lock Time
            </h3>
            <p className="text-sm text-slate-300">
              How many minutes do you want to lock your distracting apps?
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
            <div className="space-y-2">
              <label
                htmlFor="prescribed-time-input"
                className="block text-sm font-medium text-slate-200"
              >
                Prescribed Duration (Minutes)
              </label>
              <div className="flex items-center gap-3">
                <input
                  id="prescribed-time-input"
                  type="number"
                  min={1}
                  max={480}
                  value={customInput}
                  onChange={(e) => handleMinutesChange(e.target.value)}
                  className="w-36 px-4 py-2.5 text-lg font-mono font-semibold tabular-nums text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <span className="text-sm text-slate-300">minutes</span>
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-xs font-medium text-slate-400">
                Quick Presets
              </span>
              <div className="flex flex-wrap gap-2">
                {TIME_PRESETS.map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => handleSelectPreset(mins)}
                    className={`px-3.5 py-2 text-sm font-mono tabular-nums rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                      prescribedMinutes === mins
                        ? "border-blue-500 bg-blue-600 text-white font-semibold"
                        : "border-[#263D6B] bg-[#0A1730] text-slate-200 hover:bg-[#13264A]"
                    }`}
                  >
                    {mins} min
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-[#1E335C] flex items-center justify-between gap-4">
            <p className="text-xs text-slate-400">
              Lock duration set to{" "}
              <span className="font-mono font-semibold text-white tabular-nums">
                {prescribedMinutes} min
              </span>
              . Next, choose which apps to lock and which apps to allow.
            </p>

            <button
              type="button"
              disabled={!prescribedMinutes || prescribedMinutes < 1}
              onClick={onGoToSelectApps}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
            >
              <span>Next</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Apps List (Lock vs Allow Access) + "Let's start the timer." + Next */}
      {phase === "select_apps" && (
        <div className="p-6 bg-[#0F1F3D] border border-[#1E335C] rounded-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <p className="text-xs font-medium text-blue-400">
                Step 2 of 2 · Prescribed Time: {prescribedMinutes} min
              </p>
              <h3 className="text-xl font-semibold text-white">
                Choose Apps to Block &amp; Apps to Give Access
              </h3>
              <p className="text-sm text-slate-300">
                Select which apps Focus_Lock should lock and stop working, and which apps you want to keep accessible.
              </p>
            </div>

            <button
              type="button"
              onClick={onOpenAddApp}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
            >
              <Plus size={14} />
              Add App
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {apps.map((app) => {
              const isBlocked = blockedAppIds.includes(app.id);
              return (
                <div
                  key={app.id}
                  className="p-3.5 rounded-lg border border-[#1E335C] bg-[#0A1730] flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <AppGlyph
                      name={app.name}
                      category={app.category}
                      accentColor={app.accentColor}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-white truncate">{app.name}</p>
                      <p className="text-xs text-slate-400 truncate">{app.category}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 p-1 bg-[#0F1F3D] border border-[#1E335C] rounded-lg shrink-0">
                    <button
                      type="button"
                      onClick={() => onToggleAppAccess(app.id, "block")}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                        isBlocked
                          ? "bg-rose-600 text-white"
                          : "text-slate-300 hover:text-white"
                      }`}
                    >
                      <Lock size={12} />
                      Block
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleAppAccess(app.id, "allow")}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                        !isBlocked
                          ? "bg-emerald-600 text-white"
                          : "text-slate-300 hover:text-white"
                      }`}
                    >
                      <LockOpen size={12} />
                      Allow
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Prompt: "Let's start the timer." + Next button */}
          <div className="pt-4 border-t border-[#1E335C] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <button
              type="button"
              onClick={onBackToSetTime}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap self-start sm:self-auto"
            >
              <ArrowLeft size={15} />
              Back to Time
            </button>

            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <p className="text-sm font-medium text-blue-200">
                {blockedAppIds.length} blocked · {allowedAppIds.length} allowed — Let&apos;s start the timer.
              </p>
              <button
                type="button"
                disabled={blockedAppIds.length === 0}
                onClick={onStartTimer}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0"
              >
                <span>Next</span>
                <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 3 & 4: Timer Running or Completed Notification */}
      {(phase === "running" || phase === "completed") && (
        <div className="space-y-6">
          {/* Completion Notification Banner */}
          {phase === "completed" && (
            <div
              role="status"
              className="p-6 bg-emerald-950/70 border border-emerald-600/70 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-3.5">
                <CheckCircle2 size={24} className="text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="text-lg font-semibold text-white">
                    The time has ended. Congratulations, you haven&apos;t unlocked those apps.
                  </h3>
                  <p className="text-sm text-emerald-100">
                    All {blockedApps.length} paused and stopped apps ({blockedApps.map((a) => a.name).join(", ")}) now have full access restored.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onResetWorkflow}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-900 bg-white rounded-lg hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 self-start md:self-auto"
              >
                <RotateCcw size={15} />
                New Focus_Lock Session
              </button>
            </div>
          )}

          {/* Active Countdown Card */}
          {phase === "running" && (
            <div className="p-6 bg-[#0F1F3D] border border-blue-500/50 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-medium text-blue-300">
                  <Shield size={15} />
                  <span>Focus_Lock Active · {prescribedMinutes}-Minute Lock</span>
                </div>
                <p className="font-mono text-4xl font-bold tabular-nums text-white">
                  {formatTimer(remainingSeconds)}
                </p>
                <p className="text-xs text-slate-300">
                  Selected distracting apps are locked and stopped until this timer finishes.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 shrink-0">
                <div className="px-4 py-2.5 rounded-lg bg-[#0A1730] border border-[#1E335C]">
                  <span className="block text-[11px] text-slate-400">Session Time Active</span>
                  <span className="font-mono text-base font-semibold tabular-nums text-white">
                    {formatTimer(sessionElapsedSeconds)}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={onResetWorkflow}
                  className="px-4 py-2.5 text-xs font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap"
                >
                  Change Settings
                </button>
              </div>
            </div>
          )}

          {/* Comprehensive Status Notification Card */}
          <div className="p-6 bg-[#0F1F3D] border border-[#1E335C] rounded-xl space-y-5">
            <div className="flex items-center gap-2.5 border-b border-[#1E335C] pb-3">
              <Bell size={18} className="text-blue-400" />
              <h3 className="text-base font-semibold text-white">
                Focus_Lock Status Notification
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
              <div className="p-4 rounded-lg bg-[#0A1730] border border-[#1E335C] space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-medium text-rose-300">
                  <Lock size={14} />
                  <span>
                    {phase === "running"
                      ? "Blocked / Stopped Working Apps"
                      : "Access Restored Apps"}
                  </span>
                </div>
                <p className="font-semibold text-white">
                  {blockedApps.length > 0
                    ? blockedApps.map((a) => a.name).join(", ")
                    : "None"}
                </p>
                <p className="text-xs text-slate-400">
                  {phase === "running"
                    ? `${blockedApps.length} apps paused until timer ends`
                    : `${blockedApps.length} apps unlocked after completion`}
                </p>
              </div>

              <div className="p-4 rounded-lg bg-[#0A1730] border border-[#1E335C] space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-medium text-emerald-300">
                  <LockOpen size={14} />
                  <span>Allowed / Accessible Apps</span>
                </div>
                <p className="font-semibold text-white">
                  {allowedApps.length > 0
                    ? allowedApps.map((a) => a.name).join(", ")
                    : "None"}
                </p>
                <p className="text-xs text-slate-400">
                  {allowedApps.length} apps open for normal use
                </p>
              </div>

              <div className="p-4 rounded-lg bg-[#0A1730] border border-[#1E335C] space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-medium text-blue-300">
                  <ShieldCheck size={14} />
                  <span>Protected Apps</span>
                </div>
                <p className="font-semibold text-white">
                  {protectedApps.length > 0
                    ? protectedApps.map((a) => a.name).join(", ")
                    : "None"}
                </p>
                <p className="text-xs text-slate-400">
                  {protectedApps.length} total apps under Focus_Lock
                </p>
              </div>

              <div className="p-4 rounded-lg bg-[#0A1730] border border-[#1E335C] space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-medium text-emerald-300">
                  <CheckCircle2 size={14} />
                  <span>Apps at Completed Level</span>
                </div>
                <p className="font-semibold text-white">
                  {completedApps.length > 0
                    ? completedApps.map((a) => a.name).join(", ")
                    : phase === "completed"
                      ? blockedApps.map((a) => a.name).join(", ")
                      : `${totalCompletedSessions} verified sessions`}
                </p>
                <p className="text-xs text-slate-400">
                  {totalCompletedSessions} task-to-unlock completions logged
                </p>
              </div>

              <div className="p-4 rounded-lg bg-[#0A1730] border border-[#1E335C] space-y-1.5 md:col-span-2 lg:col-span-2">
                <div className="flex items-center gap-2 text-xs font-medium text-amber-300">
                  <Clock size={14} />
                  <span>Time Using Focus_Lock</span>
                </div>
                <div className="flex flex-wrap items-baseline gap-6">
                  <div>
                    <span className="font-mono text-lg font-bold tabular-nums text-white">
                      {formatTimer(sessionElapsedSeconds)}
                    </span>
                    <span className="text-xs text-slate-400 ml-2">current lock session</span>
                  </div>
                  <div>
                    <span className="font-mono text-lg font-bold tabular-nums text-blue-300">
                      {formatTimer(totalAppUsageSeconds)}
                    </span>
                    <span className="text-xs text-slate-400 ml-2">total time in Focus_Lock</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive App Access Grid */}
          <div className="p-6 bg-[#0F1F3D] border border-[#1E335C] rounded-xl space-y-4">
            <h3 className="text-sm font-semibold text-white">
              Live Application Status (Click any app to test access)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {apps.map((app) => {
                const isBlockedNow = phase === "running" && blockedAppIds.includes(app.id);
                return (
                  <button
                    key={app.id}
                    type="button"
                    onClick={() => onTryOpenApp(app)}
                    className="p-3.5 rounded-lg border border-[#1E335C] bg-[#0A1730] hover:bg-[#13264A] flex items-center justify-between gap-3 text-left transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <AppGlyph
                        name={app.name}
                        category={app.category}
                        accentColor={app.accentColor}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{app.name}</p>
                        <p className="text-xs text-slate-400 truncate">{app.category}</p>
                      </div>
                    </div>

                    {isBlockedNow ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-400 shrink-0">
                        <Lock size={13} />
                        Stopped
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 shrink-0">
                        <LockOpen size={13} />
                        Accessible
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
