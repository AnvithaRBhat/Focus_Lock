import React, { useState } from "react";
import { Shield, Play, Square, Lock } from "lucide-react";
import type { FocusSessionState, ProtectedApp } from "../types";
import { AppGlyph } from "./AppGlyph";

interface FocusModeViewProps {
  apps: ProtectedApp[];
  focusSession: FocusSessionState;
  remainingFocusSeconds: number;
  onStartFocus: (durationMinutes: number, label: string) => void;
  onStopFocus: () => void;
  onTryOpenApp: (app: ProtectedApp) => void;
}

const PRESET_DURATIONS = [15, 25, 45, 60];

export const FocusModeView: React.FC<FocusModeViewProps> = ({
  apps,
  focusSession,
  remainingFocusSeconds,
  onStartFocus,
  onStopFocus,
  onTryOpenApp,
}) => {
  const [selectedMinutes, setSelectedMinutes] = useState(25);
  const [sessionLabel, setSessionLabel] = useState("Deep Study Sprint");

  const protectedApps = apps.filter((a) => a.isProtected);

  const mins = Math.floor(remainingFocusSeconds / 60);
  const secs = remainingFocusSeconds % 60;
  const formattedClock = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 bg-[#0F1F3D] border border-[#1E335C] rounded-xl space-y-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold text-white">
                Focus Mode Shield
              </h2>
              <p className="text-sm text-slate-300 mt-1">
                Lock all distracting applications during dedicated study blocks so your attention remains uninterrupted.
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs font-medium shrink-0">
              <Shield
                size={16}
                className={focusSession.isActive ? "text-amber-400" : "text-slate-400"}
              />
              <span className={focusSession.isActive ? "text-amber-300" : "text-slate-400"}>
                {focusSession.isActive ? "Shield Active" : "Standby"}
              </span>
            </div>
          </div>

          {focusSession.isActive ? (
            <div className="p-6 rounded-lg border border-amber-700/70 bg-amber-950/50 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
              <div>
                <p className="text-xs font-medium text-amber-300">{focusSession.label}</p>
                <p className="font-mono text-4xl font-bold tabular-nums text-white mt-1">
                  {formattedClock}
                </p>
                <p className="text-xs text-slate-300 mt-2">
                  All {protectedApps.length} protected applications are strictly restricted until this session ends.
                </p>
              </div>
              <button
                type="button"
                onClick={onStopFocus}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-900 bg-white rounded-lg hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 self-start sm:self-center"
              >
                <Square size={15} />
                End Focus Session
              </button>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="focus-session-label"
                    className="block text-sm font-medium text-slate-200 mb-1.5"
                  >
                    Session Goal
                  </label>
                  <input
                    id="focus-session-label"
                    type="text"
                    value={sessionLabel}
                    onChange={(e) => setSessionLabel(e.target.value)}
                    placeholder="e.g., Chapter 4 Literature Review"
                    className="w-full px-3.5 py-2 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <span className="block text-sm font-medium text-slate-200 mb-1.5">
                    Duration (Minutes)
                  </span>
                  <div className="flex items-center gap-2">
                    {PRESET_DURATIONS.map((dur) => (
                      <button
                        key={dur}
                        type="button"
                        onClick={() => setSelectedMinutes(dur)}
                        className={`flex-1 py-2 text-sm font-mono tabular-nums rounded-lg border transition-colors ${
                          selectedMinutes === dur
                            ? "border-blue-500 bg-blue-600/25 text-blue-200 font-semibold"
                            : "border-[#263D6B] bg-[#0A1730] text-slate-300 hover:bg-[#13264A]"
                        }`}
                      >
                        {dur}m
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() =>
                  onStartFocus(selectedMinutes, sessionLabel.trim() || "Deep Study Sprint")
                }
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0"
              >
                <Play size={16} />
                Activate {selectedMinutes}-Minute Focus Mode
              </button>
            </div>
          )}
        </div>

        <div className="p-6 bg-[#0F1F3D] border border-[#1E335C] rounded-xl space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Restricted During Focus ({protectedApps.length})
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Click any app to test Focus Mode enforcement.
            </p>
          </div>

          <div className="divide-y divide-[#1E335C]">
            {protectedApps.map((app) => (
              <button
                key={app.id}
                type="button"
                onClick={() => onTryOpenApp(app)}
                className="w-full py-2.5 flex items-center justify-between gap-3 text-left hover:bg-[#162B52] px-2 -mx-2 rounded-lg transition-colors"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <AppGlyph
                    name={app.name}
                    category={app.category}
                    accentColor={app.accentColor}
                    size="sm"
                  />
                  <span className="text-sm font-medium text-slate-100 truncate">
                    {app.name}
                  </span>
                </div>
                <span className="inline-flex items-center gap-1 text-xs text-slate-400 shrink-0">
                  <Lock size={13} />
                  {focusSession.isActive ? "Shielded" : app.status === "unlocked" ? "Open" : "Locked"}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
