import React, { useState } from "react";
import { X, SlidersHorizontal } from "lucide-react";
import type {
  ActivityType,
  DifficultyLevel,
  ProtectedApp,
  UnlockRule,
} from "../types";

interface RuleEditorModalProps {
  isOpen: boolean;
  editingRule: UnlockRule | null;
  apps: ProtectedApp[];
  preselectedAppId?: string | null;
  onClose: () => void;
  onSaveRule: (rule: UnlockRule, assignedAppIds: string[]) => void;
}

const DEFAULT_UNITS: Record<ActivityType, string> = {
  Reading: "pages",
  Writing: "words",
  Assignment: "minutes",
  Revision: "chapters",
};

export const RuleEditorModal: React.FC<RuleEditorModalProps> = ({
  isOpen,
  editingRule,
  apps,
  preselectedAppId,
  onClose,
  onSaveRule,
}) => {
  const initialAssigned = editingRule
    ? apps.filter((a) => a.ruleId === editingRule.id).map((a) => a.id)
    : preselectedAppId
      ? [preselectedAppId]
      : [];

  const [name, setName] = useState(editingRule?.name ?? "Custom Study Sequence");
  const [activityType, setActivityType] = useState<ActivityType>(
    editingRule?.activityType ?? "Reading",
  );
  const [targetAmount, setTargetAmount] = useState<number>(editingRule?.targetAmount ?? 5);
  const [targetUnit, setTargetUnit] = useState<string>(editingRule?.targetUnit ?? "pages");
  const [questionCount, setQuestionCount] = useState<number>(editingRule?.questionCount ?? 5);
  const [difficulty, setDifficulty] = useState<DifficultyLevel>(
    editingRule?.difficulty ?? "Standard",
  );
  const [passingScore, setPassingScore] = useState<number>(editingRule?.passingScore ?? 70);
  const [unlockDurationMinutes, setUnlockDurationMinutes] = useState<number>(
    editingRule?.unlockDurationMinutes ?? 30,
  );
  const [assignedAppIds, setAssignedAppIds] = useState<string[]>(initialAssigned);

  if (!isOpen) return null;

  const handleActivityChange = (next: ActivityType) => {
    setActivityType(next);
    setTargetUnit(DEFAULT_UNITS[next]);
    if (next === "Writing" && targetAmount < 50) setTargetAmount(300);
    if (next === "Reading" && targetAmount > 50) setTargetAmount(5);
    if (next === "Assignment" && targetAmount < 15) setTargetAmount(30);
    if (next === "Revision" && targetAmount > 20) setTargetAmount(3);
  };

  const toggleAppSelection = (appId: string) => {
    setAssignedAppIds((prev) =>
      prev.includes(appId) ? prev.filter((id) => id !== appId) : [...prev, appId],
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const rule: UnlockRule = {
      id: editingRule?.id ?? `rule-${Date.now()}`,
      name: name.trim() || "Custom Unlock Rule",
      activityType,
      targetAmount: Math.max(1, targetAmount),
      targetUnit: targetUnit.trim() || "units",
      questionCount: Math.min(Math.max(1, questionCount), 10),
      difficulty,
      passingScore: Math.min(Math.max(40, passingScore), 100),
      unlockDurationMinutes: Math.min(Math.max(5, unlockDurationMinutes), 180),
      isSharedRule: assignedAppIds.length > 1,
    };

    onSaveRule(rule, assignedAppIds);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-[2px] p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="rule-editor-title"
    >
      <div className="w-full max-w-2xl bg-[#0F1F3D] border border-[#1E335C] rounded-xl shadow-xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#1E335C] shrink-0">
          <div className="flex items-center gap-2.5">
            <SlidersHorizontal size={18} className="text-blue-400" />
            <h2 id="rule-editor-title" className="text-base font-semibold text-white">
              {editingRule ? "Edit Unlock Rule" : "Create Custom Unlock Rule"}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#162B52] transition-colors"
            aria-label="Close rule editor"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto">
          <div>
            <label htmlFor="rule-name" className="block text-sm font-medium text-slate-200 mb-1.5">
              Rule Name
            </label>
            <input
              id="rule-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Evening Study Sequence"
              className="w-full px-3.5 py-2 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="rule-activity" className="block text-sm font-medium text-slate-200 mb-1.5">
                Level 1 Activity
              </label>
              <select
                id="rule-activity"
                value={activityType}
                onChange={(e) => handleActivityChange(e.target.value as ActivityType)}
                className="w-full px-3.5 py-2 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Reading">Reading</option>
                <option value="Writing">Writing</option>
                <option value="Assignment">Assignment</option>
                <option value="Revision">Revision</option>
              </select>
            </div>

            <div>
              <label htmlFor="rule-target-amount" className="block text-sm font-medium text-slate-200 mb-1.5">
                Target Amount
              </label>
              <input
                id="rule-target-amount"
                type="number"
                min={1}
                max={5000}
                value={targetAmount}
                onChange={(e) => setTargetAmount(Number(e.target.value))}
                className="w-full px-3.5 py-2 text-sm font-mono tabular-nums text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="rule-target-unit" className="block text-sm font-medium text-slate-200 mb-1.5">
                Target Unit
              </label>
              <input
                id="rule-target-unit"
                type="text"
                required
                value={targetUnit}
                onChange={(e) => setTargetUnit(e.target.value)}
                placeholder="pages / minutes / words"
                className="w-full px-3.5 py-2 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label htmlFor="rule-questions" className="block text-sm font-medium text-slate-200 mb-1.5">
                AI Questions
              </label>
              <input
                id="rule-questions"
                type="number"
                min={1}
                max={10}
                value={questionCount}
                onChange={(e) => setQuestionCount(Number(e.target.value))}
                className="w-full px-3.5 py-2 text-sm font-mono tabular-nums text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="rule-difficulty" className="block text-sm font-medium text-slate-200 mb-1.5">
                Difficulty
              </label>
              <select
                id="rule-difficulty"
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as DifficultyLevel)}
                className="w-full px-3.5 py-2 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Foundational">Foundational</option>
                <option value="Standard">Standard</option>
                <option value="Challenging">Challenging</option>
              </select>
            </div>

            <div>
              <label htmlFor="rule-passing" className="block text-sm font-medium text-slate-200 mb-1.5">
                Pass Score (%)
              </label>
              <input
                id="rule-passing"
                type="number"
                min={40}
                max={100}
                step={5}
                value={passingScore}
                onChange={(e) => setPassingScore(Number(e.target.value))}
                className="w-full px-3.5 py-2 text-sm font-mono tabular-nums text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="rule-duration" className="block text-sm font-medium text-slate-200 mb-1.5">
                Unlock (mins)
              </label>
              <input
                id="rule-duration"
                type="number"
                min={5}
                max={180}
                step={5}
                value={unlockDurationMinutes}
                onChange={(e) => setUnlockDurationMinutes(Number(e.target.value))}
                className="w-full px-3.5 py-2 text-sm font-mono tabular-nums text-white bg-[#0A1730] border border-[#263D6B] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="pt-2 border-t border-[#1E335C]">
            <div className="flex items-center justify-between mb-2.5">
              <div>
                <p className="text-sm font-medium text-white">
                  Assign Applications to This Rule
                </p>
                <p className="text-xs text-slate-400">
                  Select one app for an individual rule, or multiple apps to share one common task sequence.
                </p>
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-300">
                {assignedAppIds.length} selected
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {apps.map((app) => {
                const selected = assignedAppIds.includes(app.id);
                return (
                  <button
                    key={app.id}
                    type="button"
                    onClick={() => toggleAppSelection(app.id)}
                    className={`flex items-center justify-between px-3 py-2 text-sm rounded-lg border text-left transition-colors ${
                      selected
                        ? "border-blue-500 bg-blue-600/25 text-blue-100 font-medium"
                        : "border-[#263D6B] bg-[#0A1730] text-slate-300 hover:bg-[#13264A]"
                    }`}
                  >
                    <span className="truncate">{app.name}</span>
                    <span
                      className={`w-4 h-4 rounded border flex items-center justify-center text-[10px] shrink-0 ${
                        selected
                          ? "bg-blue-600 border-blue-500 text-white"
                          : "border-slate-500 bg-[#071124]"
                      }`}
                    >
                      {selected ? "✓" : ""}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#1E335C]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap shrink-0"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0"
            >
              Save Unlock Rule
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
