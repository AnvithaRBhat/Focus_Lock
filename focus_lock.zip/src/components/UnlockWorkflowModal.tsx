import React, { useEffect, useRef, useState } from "react";
import {
  X,
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  LockOpen,
  Play,
  Pause,
  RotateCcw,
  Loader2,
  ShieldCheck,
} from "lucide-react";
import type {
  EvaluationResult,
  GeneratedQuestion,
  ProtectedApp,
  UnlockRule,
  UnlockSessionRecord,
  UploadedEvidenceFile,
} from "../types";
import { SAMPLE_STUDY_MATERIALS } from "../data/defaults";
import { AppGlyph } from "./AppGlyph";

interface UnlockWorkflowModalProps {
  isOpen: boolean;
  targetApps: ProtectedApp[];
  rule: UnlockRule | null;
  onClose: () => void;
  onCompleteUnlock: (
    unlockedAppIds: string[],
    record: UnlockSessionRecord,
  ) => void;
  onUpdateLevelProgress?: (appIds: string[], level: 1 | 2 | 3) => void;
}

export const UnlockWorkflowModal: React.FC<UnlockWorkflowModalProps> = ({
  isOpen,
  targetApps,
  rule,
  onClose,
  onCompleteUnlock,
  onUpdateLevelProgress,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [materialText, setMaterialText] = useState("");
  const [uploadedFile, setUploadedFile] = useState<UploadedEvidenceFile | null>(null);
  const [taskConfirmed, setTaskConfirmed] = useState(false);

  const [timerRunning, setTimerRunning] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generateError, setGenerateError] = useState<string | null>(null);
  const [topicTitle, setTopicTitle] = useState("Study Verification");
  const [questions, setQuestions] = useState<GeneratedQuestion[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evaluateError, setEvaluateError] = useState<string | null>(null);
  const [evaluationResult, setEvaluationResult] = useState<EvaluationResult | null>(null);

  const [isGranted, setIsGranted] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!timerRunning) return;
    const interval = window.setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(interval);
  }, [timerRunning]);

  if (!isOpen || !rule || targetApps.length === 0) return null;

  const targetAppIds = targetApps.map((a) => a.id);
  const appNamesLabel = targetApps.map((a) => a.name).join(", ");

  const formatDuration = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  const handleFileSelected = async (file: File | undefined) => {
    if (!file) return;
    setGenerateError(null);

    const maxBytes = 12 * 1024 * 1024;
    if (file.size > maxBytes) {
      setGenerateError("File exceeds 12 MB limit. Please upload a smaller PDF, image, or text note.");
      return;
    }

    if (
      file.type === "text/plain" ||
      file.type === "text/markdown" ||
      file.name.endsWith(".txt") ||
      file.name.endsWith(".md")
    ) {
      const text = await file.text();
      setMaterialText((prev) => (prev ? `${prev}\n\n${text}` : text));
      setUploadedFile({
        name: file.name,
        mimeType: "text/plain",
        data: "",
        sizeBytes: file.size,
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.includes(",") ? result.split(",")[1] : result;
      setUploadedFile({
        name: file.name,
        mimeType: file.type || "application/pdf",
        data: base64,
        sizeBytes: file.size,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleGenerateQuestions = async () => {
    setGenerateError(null);
    if (!materialText.trim() && !uploadedFile?.data) {
      setGenerateError(
        "Please paste your reading summary, write notes, or upload a study PDF before continuing.",
      );
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch("/api/gemini/generate-questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          materialText,
          fileData: uploadedFile?.data
            ? {
                mimeType: uploadedFile.mimeType,
                data: uploadedFile.data,
                name: uploadedFile.name,
              }
            : null,
          questionCount: rule.questionCount,
          difficulty: rule.difficulty,
          activityType: rule.activityType,
          taskTarget: `${rule.targetAmount} ${rule.targetUnit}`,
          appNames: targetApps.map((a) => a.name),
        }),
      });

      const data = (await response.json()) as {
        error?: string;
        topicTitle?: string;
        questions?: GeneratedQuestion[];
      };

      if (!response.ok || data.error) {
        throw new Error(data.error || "Unable to generate comprehension questions.");
      }

      if (!data.questions || data.questions.length === 0) {
        throw new Error("No questions were generated. Please include more detailed study notes.");
      }

      setTopicTitle(data.topicTitle || "Submitted Study Material");
      setQuestions(data.questions);
      setAnswers({});
      setEvaluationResult(null);
      setTimerRunning(false);
      setStep(2);
      onUpdateLevelProgress?.(targetAppIds, 2);
    } catch (err) {
      setGenerateError(
        err instanceof Error ? err.message : "Failed to generate comprehension questions.",
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEvaluateAnswers = async () => {
    setEvaluateError(null);
    const unanswered = questions.some((q) => !(answers[q.id] ?? "").trim());
    if (unanswered) {
      setEvaluateError("Please answer every question before submitting for verification.");
      return;
    }

    setIsEvaluating(true);
    try {
      const response = await fetch("/api/gemini/evaluate-answers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          materialText,
          fileData: uploadedFile?.data
            ? {
                mimeType: uploadedFile.mimeType,
                data: uploadedFile.data,
              }
            : null,
          questions,
          answers: questions.map((q) => ({
            questionId: q.id,
            answerText: answers[q.id] ?? "",
          })),
          passingScore: rule.passingScore,
          difficulty: rule.difficulty,
        }),
      });

      const data = (await response.json()) as EvaluationResult & { error?: string };
      if (!response.ok || data.error) {
        throw new Error(data.error || "Failed to evaluate answers.");
      }

      setEvaluationResult(data);
      if (data.passed) {
        onUpdateLevelProgress?.(targetAppIds, 3);
      }
    } catch (err) {
      setEvaluateError(
        err instanceof Error ? err.message : "Error evaluating your answers.",
      );
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleGrantAccess = () => {
    if (!evaluationResult?.passed) return;
    const record: UnlockSessionRecord = {
      id: `session-${Date.now()}`,
      timestamp: Date.now(),
      appIds: targetAppIds,
      appNames: targetApps.map((a) => a.name),
      ruleName: rule.name,
      activityType: rule.activityType,
      targetSummary: `${rule.targetAmount} ${rule.targetUnit} completed`,
      topicTitle,
      questionCount: questions.length,
      difficulty: rule.difficulty,
      score: evaluationResult.overallScore,
      passed: true,
      durationMinutes: rule.unlockDurationMinutes,
    };

    onCompleteUnlock(targetAppIds, record);
    setIsGranted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-[2px] p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="unlock-workflow-title"
    >
      <div className="w-full max-w-4xl bg-[#0F1F3D] border border-[#1E335C] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#1E335C] bg-[#0B1830] shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex -space-x-1.5 shrink-0">
              {targetApps.slice(0, 3).map((app) => (
                <AppGlyph
                  key={app.id}
                  name={app.name}
                  category={app.category}
                  accentColor={app.accentColor}
                  size="sm"
                />
              ))}
            </div>
            <div className="min-w-0">
              <h2
                id="unlock-workflow-title"
                className="text-base font-semibold text-white truncate"
              >
                Unlock {appNamesLabel}
              </h2>
              <p className="text-xs text-slate-400 truncate">
                {rule.name} · {rule.activityType} {rule.targetAmount} {rule.targetUnit} ·{" "}
                {rule.questionCount} questions ({rule.passingScore}% pass)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-[#162B52] rounded-lg transition-colors"
            aria-label="Close unlock workflow"
          >
            <X size={18} />
          </button>
        </div>

        {/* 3-Level Progress Bar */}
        <div className="grid grid-cols-3 border-b border-[#1E335C] bg-[#0A1730] text-xs shrink-0">
          {[
            { num: 1, title: "Level 1 · Task & Evidence" },
            { num: 2, title: "Level 2 · AI Verification" },
            { num: 3, title: "Level 3 · Final Unlock" },
          ].map((lvl) => {
            const active = step === lvl.num;
            const completed = step > lvl.num || (lvl.num === 3 && isGranted);
            return (
              <div
                key={lvl.num}
                className={`px-4 py-3 flex items-center gap-2 border-r last:border-r-0 border-[#1E335C] ${
                  active
                    ? "bg-[#0F1F3D] text-blue-300 font-semibold"
                    : completed
                      ? "text-emerald-400 font-medium"
                      : "text-slate-400"
                }`}
              >
                {completed ? (
                  <CheckCircle2 size={15} className="text-emerald-400 shrink-0" />
                ) : (
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center font-mono text-[11px] tabular-nums shrink-0 ${
                      active
                        ? "bg-blue-600 text-white"
                        : "bg-[#162B52] text-slate-300"
                    }`}
                  >
                    {lvl.num}
                  </span>
                )}
                <span className="truncate">{lvl.title}</span>
              </div>
            );
          })}
        </div>

        {/* Scrollable Workspace Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-lg border border-[#1E335C] bg-[#0A1730]">
                <div>
                  <p className="text-xs font-medium text-slate-400">Required Productive Target</p>
                  <p className="text-lg font-semibold text-white mt-0.5">
                    {rule.activityType}: {rule.targetAmount} {rule.targetUnit}
                  </p>
                  <p className="text-xs text-slate-300 mt-1">
                    Complete your target first, then upload notes, a PDF, or a summary as proof.
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="px-3.5 py-2 bg-[#0F1F3D] border border-[#263D6B] rounded-lg font-mono text-base font-semibold text-white tabular-nums">
                    {formatDuration(elapsedSeconds)}
                  </div>
                  <button
                    type="button"
                    onClick={() => setTimerRunning((r) => !r)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-100 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap shrink-0"
                  >
                    {timerRunning ? <Pause size={14} /> : <Play size={14} />}
                    {timerRunning ? "Pause Timer" : "Start Timer"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTimerRunning(false);
                      setElapsedSeconds(0);
                    }}
                    className="p-2 text-slate-400 hover:text-white bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors"
                    aria-label="Reset study timer"
                  >
                    <RotateCcw size={14} />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <label
                      htmlFor="study-material-textarea"
                      className="text-sm font-semibold text-white"
                    >
                      Reading Summary, Notes, or Excerpt
                    </label>
                    <div className="flex items-center gap-3">
                      {SAMPLE_STUDY_MATERIALS.map((sample, idx) => (
                        <button
                          key={sample.title}
                          type="button"
                          onClick={() => {
                            setMaterialText(sample.text);
                            setTaskConfirmed(true);
                            setGenerateError(null);
                          }}
                          className="text-xs font-medium text-blue-400 hover:text-blue-300 hover:underline whitespace-nowrap shrink-0"
                        >
                          Load Sample {idx + 1}
                        </button>
                      ))}
                    </div>
                  </div>

                  <textarea
                    id="study-material-textarea"
                    rows={8}
                    value={materialText}
                    onChange={(e) => setMaterialText(e.target.value)}
                    placeholder="Write a summary of the pages you just read, paste textbook notes, or describe key concepts you studied..."
                    className="w-full p-3.5 text-sm text-white bg-[#0A1730] border border-[#263D6B] rounded-lg placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 leading-relaxed"
                  />
                  <p className="text-xs text-slate-400">
                    FOCUSLOCK generates {rule.questionCount} {rule.difficulty.toLowerCase()} verification
                    questions directly from your notes or attached file.
                  </p>
                </div>

                <div className="space-y-3">
                  <span className="block text-sm font-semibold text-white">
                    Attach Document (Optional)
                  </span>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.txt,.md,image/png,image/jpeg"
                    onChange={(e) => handleFileSelected(e.target.files?.[0])}
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full p-5 border border-dashed border-[#2B467A] rounded-lg bg-[#0A1730] hover:bg-[#13264A] transition-colors flex flex-col items-center justify-center text-center gap-2"
                  >
                    <Upload size={20} className="text-blue-400" />
                    <span className="text-sm font-medium text-slate-100">
                      Upload PDF, Notes, or Image
                    </span>
                    <span className="text-xs text-slate-400">
                      Supports .pdf, .txt, .md, .png, .jpg
                    </span>
                  </button>

                  {uploadedFile && (
                    <div className="flex items-center justify-between gap-2 p-3 rounded-lg border border-[#1E335C] bg-[#0A1730]">
                      <div className="flex items-center gap-2 min-w-0">
                        <FileText size={16} className="text-blue-400 shrink-0" />
                        <div className="min-w-0">
                          <p className="text-xs font-medium text-white truncate">
                            {uploadedFile.name}
                          </p>
                          <p className="text-[11px] font-mono tabular-nums text-slate-400">
                            {(uploadedFile.sizeBytes / 1024).toFixed(1)} KB
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setUploadedFile(null)}
                        className="text-xs text-slate-400 hover:text-rose-400 whitespace-nowrap shrink-0"
                      >
                        Remove
                      </button>
                    </div>
                  )}

                  <label className="flex items-start gap-2.5 p-3 rounded-lg border border-[#1E335C] bg-[#0A1730] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={taskConfirmed}
                      onChange={(e) => setTaskConfirmed(e.target.checked)}
                      className="mt-0.5 rounded border-[#263D6B] bg-[#071124] text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-xs text-slate-200 leading-relaxed">
                      I confirm I completed my {rule.targetAmount} {rule.targetUnit}{" "}
                      {rule.activityType.toLowerCase()} target honestly.
                    </span>
                  </label>
                </div>
              </div>

              {generateError && (
                <div className="flex items-start gap-2.5 p-3.5 rounded-lg border border-rose-700/70 bg-rose-950/60 text-sm text-rose-200">
                  <AlertCircle size={18} className="text-rose-400 shrink-0 mt-0.5" />
                  <span>{generateError}</span>
                </div>
              )}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-[#1E335C]">
                <div>
                  <p className="text-xs text-slate-400">
                    Topic · {rule.difficulty} · Pass Threshold {rule.passingScore}%
                  </p>
                  <h3 className="text-lg font-semibold text-white">{topicTitle}</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs font-medium text-blue-400 hover:text-blue-300 underline self-start sm:self-auto whitespace-nowrap shrink-0"
                >
                  Edit Level 1 Material
                </button>
              </div>

              {evaluationResult && (
                <div
                  className={`p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                    evaluationResult.passed
                      ? "bg-emerald-950/60 border-emerald-700/70"
                      : "bg-amber-950/60 border-amber-700/70"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {evaluationResult.passed ? (
                      <CheckCircle2 size={20} className="text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle size={20} className="text-amber-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <p className="text-sm font-semibold text-white">
                        {evaluationResult.passed
                          ? "Verification Passed — Comprehension Confirmed"
                          : `Score Below Threshold (${rule.passingScore}% Required)`}
                      </p>
                      <p className="text-xs text-slate-200 mt-1">
                        {evaluationResult.summaryFeedback}
                      </p>
                    </div>
                  </div>
                  <div className="text-left sm:text-right shrink-0">
                    <span className="block text-xs text-slate-300">Overall Score</span>
                    <span className="font-mono text-2xl font-bold tabular-nums text-white">
                      {evaluationResult.overallScore}%
                    </span>
                  </div>
                </div>
              )}

              <div className="space-y-5">
                {questions.map((q, index) => {
                  const qEval = evaluationResult?.evaluations.find(
                    (ev) => ev.questionId === q.id,
                  );

                  return (
                    <div
                      key={q.id}
                      className="p-4 rounded-lg border border-[#1E335C] bg-[#0A1730] space-y-3"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-1">
                          <p className="text-xs font-medium text-slate-400">
                            Question {index + 1} of {questions.length} · {q.focusArea}
                          </p>
                          <p className="text-sm font-medium text-white leading-relaxed">
                            {q.prompt}
                          </p>
                        </div>

                        {qEval && (
                          <div className="flex items-center gap-1.5 shrink-0 font-mono text-xs font-semibold tabular-nums">
                            {qEval.isCorrect ? (
                              <CheckCircle2 size={15} className="text-emerald-400" />
                            ) : (
                              <AlertCircle size={15} className="text-amber-400" />
                            )}
                            <span
                              className={
                                qEval.isCorrect ? "text-emerald-400" : "text-amber-300"
                              }
                            >
                              {qEval.score}%
                            </span>
                          </div>
                        )}
                      </div>

                      <textarea
                        rows={3}
                        value={answers[q.id] ?? ""}
                        onChange={(e) =>
                          setAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))
                        }
                        placeholder="Explain your answer concisely in your own words..."
                        className="w-full p-3 text-sm text-white bg-[#0F1F3D] border border-[#263D6B] rounded-lg placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />

                      {qEval && (
                        <p className="text-xs text-slate-200 bg-[#0F1F3D] px-3 py-2 rounded border border-[#1E335C]">
                          <span className="font-semibold text-white">Evaluation: </span>
                          {qEval.feedback}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>

              {evaluateError && (
                <div className="flex items-start gap-2.5 p-3.5 rounded-lg border border-rose-700/70 bg-rose-950/60 text-sm text-rose-200">
                  <AlertCircle size={18} className="text-rose-400 shrink-0 mt-0.5" />
                  <span>{evaluateError}</span>
                </div>
              )}
            </div>
          )}

          {step === 3 && (
            <div className="py-4 space-y-6">
              <div className="p-6 rounded-xl border border-[#1E335C] bg-[#0A1730] space-y-5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    {isGranted ? <LockOpen size={20} /> : <ShieldCheck size={20} />}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">
                      {isGranted
                        ? `Access Granted to ${appNamesLabel}`
                        : "Level 3 · Final Verification Ready"}
                    </h3>
                    <p className="text-sm text-slate-300">
                      {isGranted
                        ? `Earned access active for ${rule.unlockDurationMinutes} minutes.`
                        : "All prerequisite reading and comprehension stages have been verified."}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-[#1E335C]">
                  <div>
                    <p className="text-xs text-slate-400">Level 1 Target</p>
                    <p className="text-sm font-semibold text-white mt-0.5">
                      {rule.activityType} · {rule.targetAmount} {rule.targetUnit}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Level 2 AI Verification</p>
                    <p className="text-sm font-semibold font-mono tabular-nums text-emerald-400 mt-0.5">
                      {evaluationResult?.overallScore ?? 0}% Passed ({questions.length} Qs)
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Reward Window</p>
                    <p className="text-sm font-semibold font-mono tabular-nums text-white mt-0.5">
                      {rule.unlockDurationMinutes} minutes
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-[#1E335C] bg-[#0B1830] flex items-center justify-between gap-4 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap shrink-0"
          >
            {isGranted ? "Return to Dashboard" : "Cancel"}
          </button>

          <div className="flex items-center gap-3">
            {step === 1 && (
              <button
                type="button"
                disabled={isGenerating || !taskConfirmed}
                onClick={handleGenerateQuestions}
                className="inline-flex items-center gap-2 px-5 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0"
              >
                {isGenerating ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    Generating Questions...
                  </>
                ) : (
                  <>
                    Generate {rule.questionCount} Verification Questions
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            )}

            {step === 2 && !evaluationResult?.passed && (
              <button
                type="button"
                disabled={isEvaluating}
                onClick={handleEvaluateAnswers}
                className="inline-flex items-center gap-2 px-5 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
              >
                {isEvaluating ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    Evaluating Answers...
                  </>
                ) : evaluationResult ? (
                  "Re-evaluate Revised Answers"
                ) : (
                  "Submit Answers for Evaluation"
                )}
              </button>
            )}

            {step === 2 && evaluationResult?.passed && (
              <button
                type="button"
                onClick={() => setStep(3)}
                className="inline-flex items-center gap-2 px-5 py-2 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-500 transition-colors whitespace-nowrap shrink-0"
              >
                Proceed to Level 3 Verification
                <ArrowRight size={16} />
              </button>
            )}

            {step === 3 && !isGranted && (
              <button
                type="button"
                onClick={handleGrantAccess}
                className="inline-flex items-center gap-2 px-5 py-2 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-500 transition-colors whitespace-nowrap shrink-0"
              >
                <LockOpen size={16} />
                Verify &amp; Unlock {targetApps.length > 1 ? `${targetApps.length} Apps` : targetApps[0].name}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
