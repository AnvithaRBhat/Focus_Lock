import React from "react";
import { X, Lock, LockOpen, ShieldAlert, ArrowRight } from "lucide-react";
import type { FocusSessionState, ProtectedApp, UnlockRule } from "../types";
import { AppGlyph } from "./AppGlyph";

interface ProtectedAppPreviewModalProps {
  app: ProtectedApp | null;
  rule: UnlockRule | null;
  focusSession: FocusSessionState;
  remainingUnlockSeconds: number;
  isTimerBlocked?: boolean;
  timerRemainingSeconds?: number;
  onClose: () => void;
  onStartUnlock: (app: ProtectedApp) => void;
  onRelockApp: (appId: string) => void;
}

export const ProtectedAppPreviewModal: React.FC<ProtectedAppPreviewModalProps> = ({
  app,
  rule,
  focusSession,
  remainingUnlockSeconds,
  isTimerBlocked = false,
  timerRemainingSeconds = 0,
  onClose,
  onStartUnlock,
  onRelockApp,
}) => {
  if (!app) return null;

  const isActuallyUnlocked =
    !isTimerBlocked &&
    !focusSession.isActive &&
    (!app.isProtected ||
      (app.status === "unlocked" && (remainingUnlockSeconds > 0 || app.unlockedUntil === null)));

  const displaySecs = isTimerBlocked ? timerRemainingSeconds : remainingUnlockSeconds;
  const mins = Math.floor(displaySecs / 60);
  const secs = displaySecs % 60;
  const formattedCountdown = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-[2px] p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="app-gate-title"
    >
      <div className="w-full max-w-md bg-[#0F1F3D] border border-[#1E335C] rounded-xl shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#1E335C]">
          <div className="flex items-center gap-3">
            <AppGlyph
              name={app.name}
              category={app.category}
              accentColor={app.accentColor}
              size="sm"
            />
            <span id="app-gate-title" className="text-sm font-semibold text-white">
              {app.name}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-[#162B52] rounded-lg transition-colors"
            aria-label="Close app gate"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {isTimerBlocked ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-rose-400">
                <Lock size={22} className="shrink-0" />
                <h3 className="text-base font-semibold text-white">
                  {app.name} is Blocked by Focus_Lock
                </h3>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                This application has been paused and stopped working for your prescribed Focus_Lock timer. Access will be restored automatically when the timer ends.
              </p>
              <div className="p-4 rounded-lg border border-[#1E335C] bg-[#0A1730] flex items-center justify-between">
                <span className="text-xs font-medium text-slate-300">Time Remaining</span>
                <span className="font-mono text-lg font-semibold tabular-nums text-rose-300">
                  {formattedCountdown}
                </span>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 px-4 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors"
              >
                Stay Focused
              </button>
            </div>
          ) : focusSession.isActive ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-amber-400">
                <ShieldAlert size={22} className="shrink-0" />
                <h3 className="text-base font-semibold text-white">
                  Blocked by Active Focus Mode
                </h3>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                {app.name} is strictly locked while your{" "}
                <span className="font-medium text-white">{focusSession.label}</span> session is
                active. Finish or end Focus Mode before unlocking distracting apps.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 px-4 text-sm font-medium text-slate-900 bg-white rounded-lg hover:bg-slate-200 transition-colors"
              >
                Return to Study
              </button>
            </div>
          ) : isActuallyUnlocked ? (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-950/80 border border-emerald-700/70 flex items-center justify-center text-emerald-400">
                  <LockOpen size={20} />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-white">
                    Access Granted · {app.name} Open
                  </h3>
                  <p className="text-xs text-slate-400">
                    {app.isProtected
                      ? "Available for use"
                      : "Protection currently paused for this app"}
                  </p>
                </div>
              </div>

              {app.isProtected && app.unlockedUntil !== null && remainingUnlockSeconds > 0 && (
                <div className="p-4 rounded-lg border border-[#1E335C] bg-[#0A1730] flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-300">
                    Earned Screen Time Remaining
                  </span>
                  <span className="font-mono text-lg font-semibold tabular-nums text-emerald-400">
                    {formattedCountdown}
                  </span>
                </div>
              )}

              <div className="flex items-center gap-3">
                {app.isProtected && (
                  <button
                    type="button"
                    onClick={() => {
                      onRelockApp(app.id);
                      onClose();
                    }}
                    className="flex-1 py-2 px-4 text-sm font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap"
                  >
                    Re-lock Now
                  </button>
                )}
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2 px-4 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-500 transition-colors whitespace-nowrap"
                >
                  Continue Using
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-rose-950/70 border border-rose-700/60 flex items-center justify-center text-rose-400">
                  <Lock size={20} />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-white">
                    {app.name} is Protected by Focus_Lock
                  </h3>
                  <p className="text-xs text-slate-400">
                    Earn screen time by completing your required task sequence.
                  </p>
                </div>
              </div>

              {rule && (
                <div className="p-4 rounded-lg border border-[#1E335C] bg-[#0A1730] space-y-2.5 text-xs text-slate-300">
                  <p className="font-semibold text-white">Required Unlock Pipeline:</p>
                  <ol className="space-y-1.5 list-decimal list-inside">
                    <li>
                      {rule.activityType} {rule.targetAmount} {rule.targetUnit}
                    </li>
                    <li>Submit reading summary or study document</li>
                    <li>
                      Answer {rule.questionCount} AI comprehension questions ({rule.passingScore}% pass)
                    </li>
                    <li>
                      Unlock {app.name} for {rule.unlockDurationMinutes} minutes
                    </li>
                  </ol>
                </div>
              )}

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-slate-200 bg-[#13264A] border border-[#263D6B] rounded-lg hover:bg-[#193261] transition-colors whitespace-nowrap"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onStartUnlock(app);
                  }}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap"
                >
                  Start Level 1 Task
                  <ArrowRight size={15} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
