import React from "react";
import { Plus, SlidersHorizontal, Trash2, ArrowRight, Layers } from "lucide-react";
import type { ProtectedApp, UnlockRule } from "../types";

interface TaskRulesViewProps {
  rules: UnlockRule[];
  apps: ProtectedApp[];
  onCreateRule: () => void;
  onEditRule: (rule: UnlockRule) => void;
  onDeleteRule: (ruleId: string) => void;
  onUnlockByRule: (rule: UnlockRule) => void;
}

export const TaskRulesView: React.FC<TaskRulesViewProps> = ({
  rules,
  apps,
  onCreateRule,
  onEditRule,
  onDeleteRule,
  onUnlockByRule,
}) => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E335C]">
        <div>
          <h2 className="text-lg font-semibold text-white">
            Custom Unlock Rules &amp; Shared Sequences
          </h2>
          <p className="text-sm text-slate-300 mt-0.5">
            Assign distinct tasks per application, or bind multiple apps to one shared study sequence.
          </p>
        </div>

        <button
          type="button"
          onClick={onCreateRule}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <Plus size={16} />
          Create Custom Rule
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {rules.map((rule) => {
          const linkedApps = apps.filter((a) => a.ruleId === rule.id);
          const isShared = linkedApps.length > 1;

          return (
            <div
              key={rule.id}
              className="p-5 bg-[#0F1F3D] border border-[#1E335C] rounded-xl flex flex-col justify-between gap-5"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      {isShared && <Layers size={13} className="text-blue-400" />}
                      <span>
                        {isShared
                          ? `Shared Sequence (${linkedApps.length} apps)`
                          : "Single-App Sequence"}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{rule.difficulty}</span>
                    </div>
                    <h3 className="text-base font-semibold text-white mt-1">
                      {rule.name}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => onEditRule(rule)}
                      className="p-2 text-slate-400 hover:text-white hover:bg-[#162B52] rounded-lg transition-colors"
                      aria-label={`Edit ${rule.name}`}
                    >
                      <SlidersHorizontal size={15} />
                    </button>
                    {rules.length > 1 && linkedApps.length === 0 && (
                      <button
                        type="button"
                        onClick={() => onDeleteRule(rule.id)}
                        className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-950/60 rounded-lg transition-colors"
                        aria-label={`Delete ${rule.name}`}
                      >
                        <Trash2 size={15} />
                      </button>
                    )}
                  </div>
                </div>

                <p className="text-xs text-slate-200 bg-[#0A1730] px-3 py-2.5 rounded-lg border border-[#1E335C] leading-relaxed">
                  {rule.activityType} {rule.targetAmount} {rule.targetUnit} → Submit summary → Answer{" "}
                  {rule.questionCount} questions ({rule.passingScore}% pass) → Unlock for{" "}
                  {rule.unlockDurationMinutes} mins
                </p>

                <div className="text-xs text-slate-300">
                  <span className="font-medium text-white">Protected Apps: </span>
                  {linkedApps.length > 0
                    ? linkedApps.map((a) => a.name).join(", ")
                    : "No apps assigned yet"}
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#1E335C]">
                <button
                  type="button"
                  onClick={() => onEditRule(rule)}
                  className="text-xs font-medium text-slate-300 hover:text-white whitespace-nowrap"
                >
                  Configure Target &amp; Apps
                </button>

                {linkedApps.length > 0 && (
                  <button
                    type="button"
                    onClick={() => onUnlockByRule(rule)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-blue-200 bg-blue-600/25 hover:bg-blue-600/40 border border-blue-500/40 rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    {linkedApps.length > 1
                      ? `Unlock All ${linkedApps.length} Apps`
                      : `Unlock ${linkedApps[0].name}`}
                    <ArrowRight size={13} />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
